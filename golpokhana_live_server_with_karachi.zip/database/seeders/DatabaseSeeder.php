<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            RolesAndPermissionsSeeder::class,
            HrPermissionsSeeder::class,
            HrSettingsSeeder::class,
            PayrollModuleSeeder::class,
            HrSimplifiedPayrollSeeder::class,
            HrEmployeeDataSeeder::class,
        ]);
    }
}
