<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Order;
use App\Models\DeliveryPartner;
use Carbon\Carbon;
use Mpdf\Mpdf;
use Mpdf\HTMLParserMode;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use App\Models\OrderDetail;
use App\Models\OrderKot;
use App\Models\Table;
use App\Models\PosDeletedItemHistory;
use App\Exports\OrdersExport;
use App\Support\OrderVisibility;
use Maatwebsite\Excel\Facades\Excel;
use Schema;
class OrderController extends Controller
{
    public function index(Request $request)
    {
        // 1. Stats Calculation
        // When Random Half is On, the cards count the same globally visible order set
        // used by the unfiltered Order List. Today's complete orders remain included.
        $today = Carbon::today();
        $statsQuery = OrderVisibility::apply(Order::query());
        $stats = [
            'today_orders' => (clone $statsQuery)->whereDate('orders.created_at', $today)->count(),
            'active_orders' => (clone $statsQuery)->whereIn('orders.status', ['Pending', 'Cooking', 'Processing'])->count(),
            'completed_orders' => (clone $statsQuery)->where('orders.status', 'Completed')->count(),
            'revenue_today' => (clone $statsQuery)
                ->whereDate('orders.created_at', $today)
                ->where('orders.status', 'Completed')
                ->sum('orders.grand_total'),
        ];

        // 2. Query Builder
        // একই filter logic Order List, PDF export এবং Excel export — তিন জায়গায় use হবে।
        $query = $this->buildOrderReportQuery($request);

        // When enabled by a Super Admin, show a deterministic random half of
        // matching historical orders plus every matching order from today.
        // PDF/Excel exports intentionally continue using the complete filtered query.
        $query = OrderVisibility::apply($query, $request->except('page'));

        $orders = $query->orderBy('id', 'desc')->paginate(10)->appends($request->query());

        // AJAX Response for table
        if ($request->ajax()) {
            return view('admin.order.partials._order_table', compact('orders'))->render();
        }

        return view('admin.order.index', compact('orders', 'stats'));
    }

    public function dueList(Request $request)
    {
        $query = $this->buildOrderReportQuery($request);
        $query->where('due', '>', 0);
        $orders = $query->orderBy('id', 'desc')->paginate(10)->appends($request->query());
        if ($request->ajax()) {
            return view('admin.order.partials._due_list_table', ['orders' => $orders, 'showPagination' => true])->render();
        }
        $totalDue = (clone $query)->sum('due');
        return view('admin.order.due_list', compact('orders', 'totalDue'));
    }


    public function show($id)
    {
        $order = Order::with(['customer', 'table', 'waiter', 'orderDetails', 'user', 'deliveryPartner'])->findOrFail($id);
        return view('admin.order.partials._order_details', compact('order'))->render();
    }

    /**
     * Order List/PDF/Excel/Print report এর জন্য common filtered query.
     * এখানে নতুন filter add করলে তিন জায়গায় একইভাবে কাজ করবে।
     */
    /**
     * Order report date filter parser.
     * UI now sends DD-MM-YYYY, but old Y-m-d links are still supported.
     */
    private function parseOrderFilterDate(?string $date): ?Carbon
    {
        $date = trim((string) $date);

        if ($date === '') {
            return null;
        }

        $formats = ['d-m-Y', 'd/m/Y', 'Y-m-d', 'Y/m/d'];

        foreach ($formats as $format) {
            try {
                $parsed = Carbon::createFromFormat($format, $date);
                $errors = Carbon::getLastErrors();

                if (($errors === false || (($errors['warning_count'] ?? 0) === 0 && ($errors['error_count'] ?? 0) === 0))
                    && $parsed
                    && $parsed->format($format) === $date) {
                    return $parsed;
                }
            } catch (\Throwable $e) {
                // Try next supported format.
            }
        }

        try {
            return Carbon::parse($date);
        } catch (\Throwable $e) {
            return null;
        }
    }

    private function buildOrderReportQuery(Request $request)
    {
        $query = Order::with(['customer', 'table', 'orderDetails', 'deliveryPartner']);

        // Search: order number অথবা customer name.
        $search = trim((string) $request->input('search', ''));
        if ($search !== '') {
            $query->where(function ($q) use ($search) {
                $q->where('order_number', 'like', "%{$search}%")
                  ->orWhereHas('customer', function ($c) use ($search) {
                      $c->where('name', 'like', "%{$search}%");
                  });
            });
        }

        // Status filter. "Due" is a financial state rather than an orders.status
        // value, so it filters by the remaining due amount. Because every screen/
        // PDF/Excel export reuses this query builder, the result stays consistent.
        $status = trim((string) $request->input('status', ''));
        if (strcasecmp($status, 'Due') === 0) {
            $query->where('due', '>', 0);
        } elseif ($status !== '') {
            $query->where('status', $status);
        }

        // Payment filter — Cash/Card/Mobile Banking/Split সব support করবে।
        $payment = trim((string) $request->input('payment', ''));
        if ($payment !== '') {
            $query->where('payment_type', $payment);
        }

        // Date range filter from the order page JS: date_from/date_to.
        // আগে controller শুধু date_range পড়ত, তাই PDF/Excel export অনেক সময় সব order নিয়ে নিত।
        $dateFrom = trim((string) $request->input('date_from', ''));
        $dateTo = trim((string) $request->input('date_to', ''));

        if ($dateFrom !== '' || $dateTo !== '') {
            $fromDate = $this->parseOrderFilterDate($dateFrom);
            $toDate = $this->parseOrderFilterDate($dateTo);

            if ($fromDate && $toDate) {
                $from = $fromDate->copy()->startOfDay();
                $to = $toDate->copy()->endOfDay();

                if ($from->gt($to)) {
                    [$from, $to] = [$toDate->copy()->startOfDay(), $fromDate->copy()->endOfDay()];
                }

                $query->whereBetween('created_at', [$from, $to]);
            } elseif ($fromDate) {
                $query->where('created_at', '>=', $fromDate->copy()->startOfDay());
            } elseif ($toDate) {
                $query->where('created_at', '<=', $toDate->copy()->endOfDay());
            }
        } elseif ($request->filled('date_range')) {
            // Backward compatibility for old date_range filter.
            if ($request->date_range == 'Today') {
                $query->whereDate('created_at', Carbon::today());
            } elseif ($request->date_range == 'Yesterday') {
                $query->whereDate('created_at', Carbon::yesterday());
            } elseif ($request->date_range == 'This Week') {
                $query->whereBetween('created_at', [Carbon::now()->startOfWeek(), Carbon::now()->endOfWeek()]);
            } elseif ($request->date_range == 'This Month') {
                $query->whereMonth('created_at', Carbon::now()->month)
                      ->whereYear('created_at', Carbon::now()->year);
            }
        }

        return $query;
    }

    public function exportPDF(Request $request)
    {
        // Do not send one huge HTML string to mPDF.
        // Also do not split one table across multiple WriteHTML calls.
       // Time out এবং Memory issue যেন না হয় তার জন্য লিমিট বাড়িয়ে দেওয়া হলো
        @ini_set('pcre.backtrack_limit', '10000000');
        @ini_set('memory_limit', '1024M'); // ৫১২ মেগাবাইট থেকে বাড়িয়ে ১০২৪ মেগাবাইট (১ জিবি) করা হলো
        @ini_set('max_execution_time', '300'); // ম্যাক্সিমাম এক্সিকিউশন টাইম ৫ মিনিট করা হলো
        @set_time_limit(300); // স্ক্রিপ্ট টাইমআউট ১২০ সেকেন্ড থেকে বাড়িয়ে ৩০০ সেকেন্ড করা হলো (দরকার হলে 0 দিতে পারেন আনলিমিটেড টাইমের জন্য)

        $restaurant = \App\Models\RestaurantSetting::first();
        $dateFilterLabel = $this->orderReportDateFilterLabel($request);
        $baseQuery = $this->buildOrderReportQuery($request);
        $totalOrders = (clone $baseQuery)->count();

        $mpdfTempDir = storage_path('app/mpdf');
        if (!is_dir($mpdfTempDir)) {
            @mkdir($mpdfTempDir, 0775, true);
        }

        $mpdf = new Mpdf([
            'mode' => 'utf-8',
            'format' => 'A4',
            'orientation' => 'L',
            'margin_left' => 8,
            'margin_right' => 8,
            'margin_top' => 10,
            'margin_bottom' => 12,
            'margin_header' => 5,
            'margin_footer' => 5,
            'tempDir' => $mpdfTempDir,
            'autoScriptToLang' => true,
            'autoLangToFont' => true,
            // FreeSans is bundled with mPDF and includes the ৳ glyph.
            'default_font' => 'freesans',
        ]);

        $mpdf->SetTitle('Order Report - ' . now()->format('d M, Y'));
        // This puts "Generated" on the Left, leaves the Center blank, and puts "Page" on the Right.
$mpdf->SetFooter('Generated: ' . now()->format('d M Y, h:i A') . '||Page {PAGENO} of {nbpg}');

        $mpdf->WriteHTML(view('admin.order.pdf_report', [
            'mode' => 'styles',
        ])->render(), HTMLParserMode::HEADER_CSS);

        $mpdf->WriteHTML(view('admin.order.pdf_report', [
            'mode' => 'header',
            'restaurant' => $restaurant,
            'dateFilterLabel' => $dateFilterLabel,
            'totalOrders' => $totalOrders,
        ])->render(), HTMLParserMode::HTML_BODY);

        $totals = [
            'subtotal' => 0,
            'revenue' => 0,
            'discount' => 0,
            'product_discount' => 0,
            'vat' => 0,
            'service_charge' => 0,
            'tips' => 0,
            'given' => 0,
            'change' => 0,
            'due' => 0,
        ];

        if ($totalOrders <= 0) {
            $mpdf->WriteHTML(view('admin.order.pdf_report', [
                'mode' => 'empty',
            ])->render(), HTMLParserMode::HTML_BODY);
        } else {
            (clone $baseQuery)
                ->orderBy('id', 'desc')
                ->chunk(60, function ($orders) use ($mpdf, &$totals) {
                    foreach ($orders as $order) {
                        $discountAmount = max(0, (float) ($order->discount_amount ?? 0));
                        $productDiscountAmount = max(0, (float) ($order->product_discount_amount ?? 0));
                        $vatAmount = max(0, (float) ($order->vat_tax ?? 0));
                        $serviceCharge = max(0, (float) ($order->service_charge ?? 0));
                        $tipsAmount = max(0, (float) ($order->tips_amount ?? ((float) ($order->total_paid_amount ?? 0) - (float) ($order->grand_total ?? 0))));
                        $givenMoney = max(0, (float) ($order->given_money ?? 0));
                        $changeAmount = max(0, (float) ($order->change_amount ?? 0));
                        $dueAmount = max(0, (float) ($order->due ?? 0));

                        if ($order->status === 'Completed') {
                            $totals['subtotal'] += (float) ($order->subtotal ?? 0);
                            $totals['revenue'] += (float) ($order->grand_total ?? 0);
                        }

                        $totals['discount'] += $discountAmount;
                        $totals['product_discount'] += $productDiscountAmount;
                        $totals['vat'] += $vatAmount;
                        $totals['service_charge'] += $serviceCharge;
                        $totals['tips'] += $tipsAmount;
                        $totals['given'] += $givenMoney;
                        $totals['change'] += $changeAmount;
                        $totals['due'] += $dueAmount;
                    }

                    // Important: every chunk is a complete table. No open <table>/<tbody> is carried
                    // between WriteHTML calls. This prevents mPDF "Undefined array key" table-parser errors.
                    $mpdf->WriteHTML(view('admin.order.pdf_report', [
                        'mode' => 'table',
                        'orders' => $orders,
                    ])->render(), HTMLParserMode::HTML_BODY);
                });
        }

        $mpdf->WriteHTML(view('admin.order.pdf_report', [
            'mode' => 'summary',
            'ordersCount' => $totalOrders,
            'totals' => $totals,
        ])->render(), HTMLParserMode::HTML_BODY);

        $fileName = 'Order_Report_' . now()->format('d_M_Y') . '.pdf';

        while (ob_get_level() > 0) {
            ob_end_clean();
        }

        return response($mpdf->Output($fileName, 'S'), 200, [
            'Content-Type' => 'application/pdf',
            'Content-Disposition' => 'inline; filename="' . $fileName . '"',
        ]);
    }

    private function orderReportDateFilterLabel(Request $request): string
    {
        $dateFrom = trim((string) $request->input('date_from', ''));
        $dateTo = trim((string) $request->input('date_to', ''));

        $fromDate = $this->parseOrderFilterDate($dateFrom);
        $toDate = $this->parseOrderFilterDate($dateTo);

        if ($fromDate && $toDate) {
            return $fromDate->format('d M Y') . ' - ' . $toDate->format('d M Y');
        }

        if ($fromDate) {
            return 'From ' . $fromDate->format('d M Y');
        }

        if ($toDate) {
            return 'Until ' . $toDate->format('d M Y');
        }

        if ($dateFrom !== '' || $dateTo !== '') {
            return 'Selected Date Range';
        }

        if ($request->filled('date_range')) {
            return (string) $request->date_range;
        }

        return 'All Orders';
    }

    public function exportExcel(Request $request)
    {
        // Excel export-এও PDF এবং Order List-এর same filtered data যাবে।
        $orders = $this->buildOrderReportQuery($request)->orderBy('id', 'desc')->get();
        $fileName = 'Order_Report_' . now()->format('d_M_Y') . '.xlsx';

        return Excel::download(new OrdersExport($orders), $fileName);
    }

    public function printReport(Request $request)
    {
        $restaurant = \App\Models\RestaurantSetting::first();
        $orders = $this->buildOrderReportQuery($request)->orderBy('id', 'desc')->get();

        return view('admin.order.pdf_report', [
            'mode' => 'full',
            'orders' => $orders,
            'restaurant' => $restaurant,
            'dateFilterLabel' => $this->orderReportDateFilterLabel($request),
            'printMode' => true,
        ]);
    }


    // ==========================================
    // Real-Time Notification Logic
    // ==========================================
  public function checkNotifications()
    {
        // orderDetails সহ ডাটা আনা হচ্ছে যাতে মোডালে আইটেম দেখানো যায়
        $newOrder = \App\Models\Order::with(['table', 'orderDetails'])
            ->where('status', 'QR_Pending')
            ->orderBy('id', 'asc')
            ->first();

        $waiterCall = \Illuminate\Support\Facades\DB::table('waiter_calls')
            ->join('tables', 'waiter_calls.table_id', '=', 'tables.id')
            ->where('waiter_calls.status', 'pending')
            ->select('waiter_calls.*', 'tables.table_number')
            ->orderBy('waiter_calls.id', 'asc')
            ->first();

        $kitchenUnsentTableIds = \App\Models\Order::query()
            ->whereNotNull('table_id')
            ->whereIn('status', ['QR_Pending', 'QR_Hold', 'Waiter_Hold'])
            ->pluck('table_id')
            ->map(fn ($id) => (int) $id)
            ->values();

        return response()->json([
            'status'                   => 'success',
            'order'                    => $newOrder,
            'waiter_call'              => $waiterCall,
            'kitchen_unsent_table_ids' => $kitchenUnsentTableIds,
        ]);
    }

    /**
     * Generate global KOT serial number.
     * KOT number will continue across all orders: KOT-1, KOT-2, KOT-3...
     */
    private function generateGlobalKotNumber()
    {
        $lastKotNumber = \App\Models\OrderKot::where('kot_number', 'like', 'KOT-%')
            ->selectRaw("MAX(CAST(REPLACE(kot_number, 'KOT-', '') AS UNSIGNED)) as max_number")
            ->value('max_number');

        return 'KOT-' . (((int) $lastKotNumber) + 1);
    }

   public function acceptQrOrder(Request $request)
{
    \Illuminate\Support\Facades\DB::beginTransaction();
    try {
        $order = \App\Models\Order::findOrFail($request->id);

        // ১. কাস্টমার সেটআপ
        $customerId = null;
        if ($request->customer_type == 'existing') {
            $customerId = $request->customer_id;
        } elseif ($request->customer_type == 'new') {
            $newCustomer = \App\Models\Customer::create([
                'name' => $request->customer_name,
                'phone' => $request->customer_phone
            ]);
            $customerId = $newCustomer->id;
        }

        // ২. অর্ডার আপডেট (স্ট্যাটাস, ওয়েটার, কাস্টমার এবং প্রিপারেশন টাইম)
        $order->status = 'Pending';
        $order->customer_id = $customerId;
        $order->waiter_id = $request->waiter_id;
        // প্রিপারেশন টাইম ডাটাবেজে সেভ করা হচ্ছে
        $order->preparation_time = $request->preparation_time ?? 20;
        $order->save();

        // ৩. কিচেন KOT জেনারেট করা (Global serial: KOT-1, KOT-2, KOT-3...)
        $kotNumber = $this->generateGlobalKotNumber();
        $kotId = \Illuminate\Support\Facades\DB::table('order_kots')->insertGetId([
            'order_id' => $order->id,
            'kot_number' => $kotNumber,
            'kitchen_status' => 'Pending',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // ৪. আইটেমগুলোকে KOT এর সাথে লিংক করা
        \Illuminate\Support\Facades\DB::table('order_details')
            ->where('order_id', $order->id)
            ->update(['order_kot_id' => $kotId]);

        // ৫. টেবিল Occupied করা
        if ($order->table_id) {
            \App\Models\Table::where('id', $order->table_id)->update(['initial_status' => 'Occupied']);
        }

        \Illuminate\Support\Facades\DB::commit();
        return response()->json(['status' => 'success']);

    } catch (\Exception $e) {
        \Illuminate\Support\Facades\DB::rollBack();
        return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
    }
}

    public function resolveWaiterCall(Request $request)
    {
        \Illuminate\Support\Facades\DB::table('waiter_calls')
            ->where('id', $request->id)
            ->update(['status' => 'resolved']);

        return response()->json(['status' => 'success']);
    }


    /**
     * Order edit page.
     * এখানে নতুন প্রোডাক্ট অ্যাড করার কোনো অপশন নেই।
     * Existing item quantity/payment summary edit এবং food complimentary conversion করা যাবে।
     */
    public function edit($id)
    {
        $order = Order::with(['customer', 'table', 'waiter', 'orderDetails.foodItem.addons', 'user'])->findOrFail($id);
        $taxSetting = DB::table('tax_settings')->first();

        $vatRate = (float) ($taxSetting->vat_rate ?? 0);
        $normalizedOrderType = strtolower(str_replace('_', '-', (string) $order->order_type));
        $serviceChargeRate = $normalizedOrderType === 'dine-in'
            ? (float) ($taxSetting->service_charge ?? 0)
            : 0;

        // DB-তে discount_amount calculated amount হিসেবে থাকে।
        // যদি পুরনো order percentage discount দিয়ে করা হয়, edit form-এ percentage value approximate করে দেখানো হবে।
        $discountValue = (float) ($order->discount_amount ?? 0);
        if (($order->discount_type ?? 'fixed') === 'percentage' && (float) ($order->subtotal ?? 0) > 0) {
            $discountValue = round(((float) $order->discount_amount / (float) $order->subtotal) * 100, 2);
        }

        return view('admin.order.edit', compact('order', 'taxSetting', 'vatRate', 'serviceChargeRate', 'discountValue'));
    }

    /**
     * Update order quantity + payment summary.
     * Existing food lines can also be converted to complimentary; no new item is created here.
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'items' => ['required', 'array'],
            'items.*.quantity' => ['required', 'integer', 'min:1'],
            'items.*.make_complimentary' => ['nullable', 'boolean'],
            'items.*.product_discount_type' => ['nullable', Rule::in(['fixed', 'percentage'])],
            'items.*.product_discount_value' => ['nullable', 'numeric', 'min:0'],
            'delete_item_id' => ['nullable', 'integer', 'exists:order_details,id'],
            'discount_type' => ['required', Rule::in(['fixed', 'percentage'])],
            'discount_value' => ['nullable', 'numeric', 'min:0'],
            'payment_method' => ['required', Rule::in(['Cash', 'Card', 'Mobile Banking', 'Split'])],
            'total_paid_amount' => ['nullable', 'numeric', 'min:0'],
            'tips_amount' => ['nullable', 'numeric', 'min:0'],
            'given_money' => ['nullable', 'numeric', 'min:0'],
            'change_amount' => ['nullable', 'numeric', 'min:0'],
            'paid_in_cash' => ['nullable', 'numeric', 'min:0'],
            'paid_in_card' => ['nullable', 'numeric', 'min:0'],
            'paid_in_mfc' => ['nullable', 'numeric', 'min:0'],
            'card_type' => ['nullable', 'string', 'max:100'],
            'mfs_provider' => ['nullable', 'string', 'max:100'],
            'transaction_id' => ['nullable', 'string', 'max:255'],
            'split_card_type' => ['nullable', 'string', 'max:100'],
            'split_mfs_provider' => ['nullable', 'string', 'max:100'],
            'split_card_reference' => ['nullable', 'string', 'max:255'],
            'split_mfs_reference' => ['nullable', 'string', 'max:255'],
            'delivery_partner' => ['nullable', 'nullable'],
        ]);

        $allowedCardTypes = ['Visa', 'Mastercard', 'American Express', 'UnionPay', 'JCB', 'Nexus', 'Diners Club', 'GPay', 'Bangla QR Card', 'Other'];
        $allowedMfsProviders = ['Rocket', 'bKash', 'MYCash', 'Islami Bank mCash', 'tap', 'FirstCash', 'Upay', 'OK Wallet', 'RUPALICASH', 'TeleCash', 'Islamic Wallet', 'Meghna Pay', 'Nagad', 'Bangla QR', 'LENDEN', 'Other'];
        $editPaymentMethod = (string) $request->input('payment_method');

        if ($editPaymentMethod === 'Card') {
            $editCardType = trim((string) $request->input('card_type'));
            $editReference = trim((string) $request->input('transaction_id'));

            if (!in_array($editCardType, $allowedCardTypes, true)) {
                return back()->withErrors(['card_type' => 'Please select a valid Card Name.'])->withInput();
            }
            if ($editReference === '') {
                return back()->withErrors(['transaction_id' => 'Bank / Card Reference Number is required.'])->withInput();
            }
        } elseif ($editPaymentMethod === 'Mobile Banking') {
            $editMfsProvider = trim((string) $request->input('mfs_provider'));
            $editReference = trim((string) $request->input('transaction_id'));

            if (!in_array($editMfsProvider, $allowedMfsProviders, true)) {
                return back()->withErrors(['mfs_provider' => 'Please select a valid MFS service.'])->withInput();
            }
            if ($editReference === '') {
                return back()->withErrors(['transaction_id' => 'MFS Reference Number is required.'])->withInput();
            }
        } elseif ($editPaymentMethod === 'Split') {
            $editSplitCardAmount = max(0, (float) $request->input('paid_in_card', 0));
            $editSplitMfsAmount = max(0, (float) $request->input('paid_in_mfc', 0));

            if ($editSplitCardAmount > 0) {
                $editSplitCardType = trim((string) $request->input('split_card_type'));
                $editSplitCardReference = trim((string) $request->input('split_card_reference'));

                if (!in_array($editSplitCardType, $allowedCardTypes, true)) {
                    return back()->withErrors(['split_card_type' => 'Please select a valid Card Type for the Split Bank / Card amount.'])->withInput();
                }
                if ($editSplitCardReference === '') {
                    return back()->withErrors(['split_card_reference' => 'Bank / Card Reference Number is required when a Split Bank / Card amount is entered.'])->withInput();
                }
            }

            if ($editSplitMfsAmount > 0) {
                $editSplitMfsProvider = trim((string) $request->input('split_mfs_provider'));
                $editSplitMfsReference = trim((string) $request->input('split_mfs_reference'));

                if (!in_array($editSplitMfsProvider, $allowedMfsProviders, true)) {
                    return back()->withErrors(['split_mfs_provider' => 'Please select a valid MFS service for the Split MFS amount.'])->withInput();
                }
                if ($editSplitMfsReference === '') {
                    return back()->withErrors(['split_mfs_reference' => 'MFS Reference Number is required when a Split MFS amount is entered.'])->withInput();
                }
            }
        }

        DB::beginTransaction();

        try {
            $order = Order::with('orderDetails.foodItem.addons')->lockForUpdate()->findOrFail($id);
            $inputItems = $request->input('items', []);
            $deleteItemId = $request->filled('delete_item_id') ? (int) $request->delete_item_id : null;
            $deletedItemName = null;
            $restoredComplimentaryToNormal = false;

            if ($deleteItemId && !$order->orderDetails->contains('id', $deleteItemId)) {
                DB::rollBack();

                return redirect()
                    ->back()
                    ->withInput()
                    ->with('error', 'Selected product does not belong to this order.');
            }

            $newSubtotal = 0;
            $productDiscountTotal = 0;

            foreach ($order->orderDetails as $detail) {
                if ($deleteItemId && (int) $detail->id === $deleteItemId) {
                    $currentQty = max(1, (int) ($detail->quantity ?? 1));
                    $lineSubtotal = max(0, (float) ($detail->subtotal ?? 0));
                    $addons = json_decode($detail->addons ?? '[]', true);
                    if (!is_array($addons)) {
                        $addons = [];
                    }

                    $addonTotal = 0;
                    foreach ($addons as $addon) {
                        $addonTotal += (float) ($addon['price'] ?? 0);
                    }

                    // Keep edit-page deletions in the same audit history used by POS item deletions.
                    if (Schema::hasTable('pos_deleted_item_histories')) {
                        DB::table('pos_deleted_item_histories')->insert([
                            'order_id' => $order->id,
                            'order_detail_id' => $detail->id,
                            'order_kot_id' => $detail->order_kot_id,
                            'food_id' => $detail->product_id,
                            'product_name' => $detail->product_name,
                            'unit_price' => $detail->price ?? 0,
                            'addon_total' => $addonTotal,
                            'deleted_quantity' => $currentQty,
                            'previous_quantity' => $currentQty,
                            'remaining_quantity' => 0,
                            'subtotal_removed' => $lineSubtotal,
                            'source' => 'ordered_item',
                            'cart_key' => null,
                            'cart_item_key' => null,
                            'order_type' => $order->order_type,
                            'table_id' => $order->table_id,
                            'addons' => json_encode($addons),
                            'note' => $detail->food_note ?? null,
                            'deleted_by' => auth()->id(),
                            'reason' => 'Ordered item deleted from Order List edit page',
                            'created_at' => now(),
                            'updated_at' => now(),
                        ]);
                    }

                    $deletedItemName = $detail->product_name ?: 'Product';
                    $kotId = $detail->order_kot_id;
                    $detail->delete();

                    if ($kotId && !OrderDetail::where('order_kot_id', $kotId)->exists()) {
                        OrderKot::where('id', $kotId)->delete();
                    }

                    continue;
                }

                // শুধু existing detail id গুলোই update হবে, নতুন কোনো item create হবে না।
                if (!isset($inputItems[$detail->id])) {
                    $newSubtotal += (float) ($detail->subtotal ?? 0);
                    $productDiscountTotal += max(0, (float) ($detail->product_discount_amount ?? 0));
                    continue;
                }

                $itemInput = $inputItems[$detail->id];
                $newQty = max(1, (int) ($itemInput['quantity'] ?? $detail->quantity));
                $oldQty = max(1, (int) ($detail->quantity ?? 1));
                $oldLineSubtotal = (float) ($detail->subtotal ?? 0);

                $isAlreadyComplimentary = !empty($detail->is_complimentary)
                    || ((float) ($detail->price ?? 0) <= 0 && $oldLineSubtotal <= 0);
                $makeComplimentary = array_key_exists('make_complimentary', $itemInput)
                    ? filter_var($itemInput['make_complimentary'], FILTER_VALIDATE_BOOLEAN)
                    : $isAlreadyComplimentary;

                if ($makeComplimentary) {
                    $addons = json_decode($detail->addons ?? '[]', true);
                    if (!is_array($addons)) {
                        $addons = [];
                    }

                    foreach ($addons as &$addon) {
                        if (is_array($addon)) {
                            $addon['price'] = 0;
                        }
                    }
                    unset($addon);

                    $detail->quantity = $newQty;
                    $detail->price = 0;
                    $detail->subtotal = 0;
                    $detail->addons = json_encode($addons);
                    $detail->product_discount_type = null;
                    $detail->product_discount_value = 0;
                    $detail->product_discount_amount = 0;

                    if (Schema::hasColumn('order_details', 'is_complimentary')) {
                        $detail->is_complimentary = 1;
                    }

                    $detail->save();
                    continue;
                }

                if ($isAlreadyComplimentary) {
                    // Complimentary rows have zero saved values, so rebuild normal price from current menu data.
                    $food = $detail->foodItem;
                    if (!$food) {
                        throw new \RuntimeException('Normal price could not be restored for "' . $detail->product_name . '" because the food item no longer exists.');
                    }

                    $normalFoodPrice = (float) ($food->discount_price ?? $food->base_price ?? 0);
                    $currentAddons = $food->addons->keyBy('id');
                    $addons = json_decode($detail->addons ?? '[]', true);
                    if (!is_array($addons)) {
                        $addons = [];
                    }

                    $addonTotal = 0;
                    foreach ($addons as &$addon) {
                        if (!is_array($addon)) {
                            continue;
                        }

                        $addonId = (int) ($addon['id'] ?? 0);
                        if ($addonId > 0 && $currentAddons->has($addonId)) {
                            $currentAddon = $currentAddons->get($addonId);
                            $addon['name'] = $currentAddon->name ?? ($addon['name'] ?? 'Addon');
                            $addon['price'] = (float) ($currentAddon->price ?? 0);
                        } else {
                            $addon['price'] = max(0, (float) ($addon['price'] ?? 0));
                        }

                        $addonTotal += (float) ($addon['price'] ?? 0);
                    }
                    unset($addon);

                    $unitTotal = $normalFoodPrice + $addonTotal;
                    $detail->price = $normalFoodPrice;
                    $detail->addons = json_encode($addons);

                    if (Schema::hasColumn('order_details', 'is_complimentary')) {
                        $detail->is_complimentary = 0;
                    }

                    $restoredComplimentaryToNormal = true;
                } elseif ($oldLineSubtotal > 0 && $oldQty > 0) {
                    // Normal existing line keeps its historical unit total.
                    $unitTotal = $oldLineSubtotal / $oldQty;
                } else {
                    $addonTotal = 0;
                    $addons = json_decode($detail->addons ?? '[]', true);
                    if (is_array($addons)) {
                        foreach ($addons as $addon) {
                            $addonTotal += (float) ($addon['price'] ?? 0);
                        }
                    }
                    $unitTotal = (float) ($detail->price ?? 0) + $addonTotal;
                }

                $newLineSubtotal = round($unitTotal * $newQty, 2);

                $productDiscountType = (($itemInput['product_discount_type'] ?? $detail->product_discount_type ?? 'fixed') === 'percentage')
                    ? 'percentage'
                    : 'fixed';
                $productDiscountValue = max(0, (float) ($itemInput['product_discount_value'] ?? $detail->product_discount_value ?? 0));

                if ($productDiscountType === 'percentage') {
                    $productDiscountValue = min($productDiscountValue, 100);
                    $productDiscountAmount = round(($newLineSubtotal * $productDiscountValue) / 100);
                } else {
                    $productDiscountAmount = min($productDiscountValue, $newLineSubtotal);
                }

                $productDiscountAmount = max(0, round($productDiscountAmount));

                $detail->quantity = $newQty;
                $detail->subtotal = $newLineSubtotal;
                $detail->product_discount_type = $productDiscountAmount > 0 ? $productDiscountType : null;
                $detail->product_discount_value = $productDiscountAmount > 0 ? $productDiscountValue : 0;
                $detail->product_discount_amount = $productDiscountAmount;
                $detail->save();

                $newSubtotal += $newLineSubtotal;
                $productDiscountTotal += $productDiscountAmount;
            }

            $taxSetting = DB::table('tax_settings')->first();
            $vatRate = (float) ($taxSetting->vat_rate ?? 0);

            $normalizedOrderType = strtolower(str_replace('_', '-', (string) $order->order_type));
            $serviceChargeRate = $normalizedOrderType === 'dine-in'
                ? (float) ($taxSetting->service_charge ?? 0)
                : 0;

            $serviceCharge = round(($newSubtotal * $serviceChargeRate) / 100);
            $vatTax = round((($newSubtotal + $serviceCharge) * $vatRate) / 100);

            $discountType = $request->discount_type ?? 'fixed';
            $discountValue = (float) ($request->discount_value ?? 0);
            $discountAmount = $discountType === 'percentage'
                ? round(($newSubtotal * $discountValue) / 100)
                : round($discountValue);

            // Other discount এবং product-wise discount আলাদা থাকবে।
            $discountAmount = min(max(0, $discountAmount), round($newSubtotal + $serviceCharge + $vatTax));
            $productDiscountTotal = min(max(0, round($productDiscountTotal)), round($newSubtotal));
            $grandTotal = max(0, round(($newSubtotal + $serviceCharge + $vatTax) - $discountAmount - $productDiscountTotal));

            $paymentMethod = $request->payment_method;
            if ($paymentMethod === 'Split') {
                $cash = max(0, (float) ($request->paid_in_cash ?? 0));
                $card = max(0, (float) ($request->paid_in_card ?? 0));
                $mfc = max(0, (float) ($request->paid_in_mfc ?? 0));
                $totalPaid = round($cash + $card + $mfc, 2);
            } else {
                $totalPaid = max(0, (float) ($request->total_paid_amount ?? 0));
                $cash = $paymentMethod === 'Cash' ? $totalPaid : 0;
                $card = $paymentMethod === 'Card' ? $totalPaid : 0;
                $mfc = $paymentMethod === 'Mobile Banking' ? $totalPaid : 0;
            }

            $tipsAmount = max(0, round((float) ($request->tips_amount ?? 0), 2));
            $givenMoney = max(0, round((float) ($request->given_money ?? 0), 2));
            $changeAmount = max(0, round($givenMoney - $totalPaid - $tipsAmount, 2));
            $due = max(0, round($grandTotal - $totalPaid, 2));

            $order->subtotal = $newSubtotal;
            $order->discount_type = $discountType;
            $order->discount_amount = $discountAmount;
            $order->product_discount_amount = $productDiscountTotal;
            $order->vat_tax = $vatTax;
            $order->service_charge = $serviceCharge;
            $order->grand_total = $grandTotal;
            $order->payment_type = $paymentMethod;

            $orderCardType = null;
            $orderMfsProvider = null;
            if ($paymentMethod === 'Card') {
                $orderCardType = trim((string) $request->input('card_type'));
            } elseif ($paymentMethod === 'Mobile Banking') {
                $orderMfsProvider = trim((string) $request->input('mfs_provider'));
            } elseif ($paymentMethod === 'Split') {
                $orderCardType = $card > 0 ? trim((string) $request->input('split_card_type')) : null;
                $orderMfsProvider = $mfc > 0 ? trim((string) $request->input('split_mfs_provider')) : null;
            }

            // Single Bank/Card or MFS keeps one required reference, just like POS.
            $order->transaction_id = in_array($paymentMethod, ['Card', 'Mobile Banking'], true)
                ? trim((string) $request->input('transaction_id'))
                : null;

            if (Schema::hasColumn('orders', 'card_type')) {
                $order->card_type = $orderCardType ?: null;
            }
            if (Schema::hasColumn('orders', 'mfs_provider')) {
                $order->mfs_provider = $orderMfsProvider ?: null;
            }
            if (Schema::hasColumn('orders', 'split_card_reference')) {
                $order->split_card_reference = $paymentMethod === 'Split' && $card > 0
                    ? trim((string) $request->input('split_card_reference'))
                    : null;
            }
            if (Schema::hasColumn('orders', 'split_mfs_reference')) {
                $order->split_mfs_reference = $paymentMethod === 'Split' && $mfc > 0
                    ? trim((string) $request->input('split_mfs_reference'))
                    : null;
            }

            $order->total_paid_amount = $totalPaid;
            $order->paid_in_cash = $cash;
            $order->paid_in_card = $card;
            $order->paid_in_mfc = $mfc;
            $order->due = $due;

            if ($restoredComplimentaryToNormal && Schema::hasColumn('orders', 'is_complimentary_order')) {
                $order->is_complimentary_order = 0;
            }

            if (Schema::hasColumn('orders', 'tips_amount')) {
                $order->tips_amount = $tipsAmount;
            }
            if (Schema::hasColumn('orders', 'given_money')) {
                $order->given_money = $givenMoney;
            }
            if (Schema::hasColumn('orders', 'change_amount')) {
                $order->change_amount = $changeAmount;
            }

            // Delivery partner can also be maintained from Order List > Edit.
            if (Schema::hasColumn('orders', 'delivery_partner')) {
                $normalizedOrderType = strtolower(trim((string) $order->order_type));
                if ($normalizedOrderType === 'delivery') {
                    $order->delivery_partner = $request->input('delivery_partner')
                        ?: ($order->delivery_partner ?: 'inhouse');
                } else {
                    $order->delivery_partner = null;
                }
            }

            $order->save();

            DB::commit();

            $successMessage = $deletedItemName
                ? 'Product "' . $deletedItemName . '" deleted and order updated successfully.'
                : 'Order updated successfully.';

            return redirect()
                ->route('order.edit', $order->id)
                ->with('success', $successMessage);
        } catch (\Exception $e) {
            DB::rollBack();

            return redirect()
                ->back()
                ->withInput()
                ->with('error', 'Order update failed! ' . $e->getMessage());
        }
    }


    /**
     * Dedicated due settlement page. Due collection and payment history live here,
     * separate from the order edit/details pages.
     */
    public function dueSettlement($id)
    {
        $order = Order::with(['customer', 'table', 'waiter', 'user', 'deliveryPartner', 'duePayments.user'])->findOrFail($id);

        return view('admin.order.due_settlement', compact('order'));
    }

    /**
     * Collect a later payment against an existing due balance and keep an auditable history.
     */
    public function payDue(Request $request, $id)
    {
        abort_unless(auth()->user()?->can('order-edit'), 403);

        $allowedCardTypes = ['Visa', 'Mastercard', 'American Express', 'UnionPay', 'JCB', 'Nexus', 'Diners Club', 'GPay', 'Bangla QR Card', 'Other'];
        $allowedMfsProviders = ['Rocket', 'bKash', 'MYCash', 'Islami Bank mCash', 'tap', 'FirstCash', 'Upay', 'OK Wallet', 'RUPALICASH', 'TeleCash', 'Islamic Wallet', 'Meghna Pay', 'Nagad', 'Bangla QR', 'LENDEN', 'Other'];

        $request->validateWithBag('duePayment', [
            'payment_type' => ['required', Rule::in(['Cash', 'Card', 'Mobile Banking', 'Split'])],
            'amount' => ['nullable', 'numeric', 'min:0'],
            'card_type' => ['nullable', 'string', 'max:100'],
            'mfs_provider' => ['nullable', 'string', 'max:100'],
            'transaction_reference' => ['nullable', 'string', 'max:255'],
            'paid_in_cash' => ['nullable', 'numeric', 'min:0'],
            'paid_in_card' => ['nullable', 'numeric', 'min:0'],
            'paid_in_mfc' => ['nullable', 'numeric', 'min:0'],
            'split_card_type' => ['nullable', 'string', 'max:100'],
            'split_mfs_provider' => ['nullable', 'string', 'max:100'],
            'split_card_reference' => ['nullable', 'string', 'max:255'],
            'split_mfs_reference' => ['nullable', 'string', 'max:255'],
            'remark' => ['nullable', 'string', 'max:1000'],
            'paid_at' => ['required', 'date_format:Y-m-d', 'before_or_equal:today'],
        ]);

        $paymentType = (string) $request->payment_type;
        $cashAmount = 0.0;
        $cardAmount = 0.0;
        $mfsAmount = 0.0;
        $amount = max(0, round((float) $request->input('amount', 0), 2));
        $cardType = null;
        $mfsProvider = null;
        $transactionReference = null;
        $splitCardReference = null;
        $splitMfsReference = null;
        $paymentDate = Carbon::createFromFormat('Y-m-d', (string) $request->input('paid_at'));
        $currentTime = now();
        $paymentDate->setTime($currentTime->hour, $currentTime->minute, $currentTime->second);

        if ($paymentType === 'Card') {
            $cardType = trim((string) $request->input('card_type'));
            $transactionReference = trim((string) $request->input('transaction_reference'));

            if (!in_array($cardType, $allowedCardTypes, true)) {
                return back()->withErrors(['card_type' => 'Please select a valid card type.'], 'duePayment')->withInput();
            }
            if ($transactionReference === '') {
                return back()->withErrors(['transaction_reference' => 'Bank / Card Reference Number is required.'], 'duePayment')->withInput();
            }
        } elseif ($paymentType === 'Mobile Banking') {
            $mfsProvider = trim((string) $request->input('mfs_provider'));
            $transactionReference = trim((string) $request->input('transaction_reference'));

            if (!in_array($mfsProvider, $allowedMfsProviders, true)) {
                return back()->withErrors(['mfs_provider' => 'Please select a valid MFS service.'], 'duePayment')->withInput();
            }
            if ($transactionReference === '') {
                return back()->withErrors(['transaction_reference' => 'MFS Reference Number is required.'], 'duePayment')->withInput();
            }
        } elseif ($paymentType === 'Split') {
            $cashAmount = max(0, round((float) $request->input('paid_in_cash', 0), 2));
            $cardAmount = max(0, round((float) $request->input('paid_in_card', 0), 2));
            $mfsAmount = max(0, round((float) $request->input('paid_in_mfc', 0), 2));
            $amount = round($cashAmount + $cardAmount + $mfsAmount, 2);

            if ($amount <= 0) {
                return back()->withErrors(['paid_in_cash' => 'Enter at least one Split payment amount.'], 'duePayment')->withInput();
            }

            if ($cardAmount > 0) {
                $cardType = trim((string) $request->input('split_card_type'));
                $splitCardReference = trim((string) $request->input('split_card_reference'));

                if (!in_array($cardType, $allowedCardTypes, true)) {
                    return back()->withErrors(['split_card_type' => 'Please select a valid card type for the Split Bank / Card amount.'], 'duePayment')->withInput();
                }
                if ($splitCardReference === '') {
                    return back()->withErrors(['split_card_reference' => 'Bank / Card Reference Number is required when a Bank / Card amount is entered.'], 'duePayment')->withInput();
                }
            }

            if ($mfsAmount > 0) {
                $mfsProvider = trim((string) $request->input('split_mfs_provider'));
                $splitMfsReference = trim((string) $request->input('split_mfs_reference'));

                if (!in_array($mfsProvider, $allowedMfsProviders, true)) {
                    return back()->withErrors(['split_mfs_provider' => 'Please select a valid MFS service for the Split MFS amount.'], 'duePayment')->withInput();
                }
                if ($splitMfsReference === '') {
                    return back()->withErrors(['split_mfs_reference' => 'MFS Reference Number is required when an MFS amount is entered.'], 'duePayment')->withInput();
                }
            }
        }

        if ($paymentType !== 'Split' && $amount <= 0) {
            return back()->withErrors(['amount' => 'Payment Amount must be greater than 0.'], 'duePayment')->withInput();
        }

        if ($paymentType === 'Cash') {
            $cashAmount = $amount;
        } elseif ($paymentType === 'Card') {
            $cardAmount = $amount;
        } elseif ($paymentType === 'Mobile Banking') {
            $mfsAmount = $amount;
        }

        DB::beginTransaction();

        try {
            $order = Order::lockForUpdate()->findOrFail($id);
            $dueBefore = max(0, round((float) ($order->due ?? 0), 2));

            if ($dueBefore <= 0) {
                DB::rollBack();
                return back()->with('error', 'This order has no due amount remaining.');
            }

            if ($amount > $dueBefore) {
                DB::rollBack();
                $amountErrorKey = $paymentType === 'Split' ? 'paid_in_cash' : 'amount';

                return back()->withErrors([
                    $amountErrorKey => 'Due payment cannot exceed the remaining due amount of ৳' . number_format($dueBefore, 2) . '.',
                ], 'duePayment')->withInput();
            }

            $dueAfter = max(0, round($dueBefore - $amount, 2));

            \App\Models\OrderDuePayment::create([
                'order_id' => $order->id,
                'amount' => $amount,
                'due_before' => $dueBefore,
                'due_after' => $dueAfter,
                'payment_type' => $paymentType,
                'transaction_reference' => in_array($paymentType, ['Card', 'Mobile Banking'], true)
                    ? $transactionReference
                    : null,
                'card_type' => $cardType,
                'mfs_provider' => $mfsProvider,
                'paid_in_cash' => $cashAmount,
                'paid_in_card' => $cardAmount,
                'paid_in_mfc' => $mfsAmount,
                'split_card_reference' => $paymentType === 'Split' && $cardAmount > 0 ? $splitCardReference : null,
                'split_mfs_reference' => $paymentType === 'Split' && $mfsAmount > 0 ? $splitMfsReference : null,
                'remark' => trim((string) $request->remark) !== '' ? trim((string) $request->remark) : null,
                'received_by' => auth()->id(),
                'paid_at' => $paymentDate,
            ]);

            $order->total_paid_amount = round((float) ($order->total_paid_amount ?? 0) + $amount, 2);
            $order->paid_in_cash = round((float) ($order->paid_in_cash ?? 0) + $cashAmount, 2);
            $order->paid_in_card = round((float) ($order->paid_in_card ?? 0) + $cardAmount, 2);
            $order->paid_in_mfc = round((float) ($order->paid_in_mfc ?? 0) + $mfsAmount, 2);

            if ($cardAmount > 0 && $cardType !== null && Schema::hasColumn('orders', 'card_type')) {
                $order->card_type = $cardType;
            }
            if ($mfsAmount > 0 && $mfsProvider !== null && Schema::hasColumn('orders', 'mfs_provider')) {
                $order->mfs_provider = $mfsProvider;
            }

            $activeMethods = collect([
                'Cash' => (float) ($order->paid_in_cash ?? 0),
                'Card' => (float) ($order->paid_in_card ?? 0),
                'Mobile Banking' => (float) ($order->paid_in_mfc ?? 0),
            ])->filter(fn ($value) => $value > 0);

            $order->payment_type = $activeMethods->count() > 1
                ? 'Split'
                : ($activeMethods->keys()->first() ?: $paymentType);
            $order->due = $dueAfter;
            $order->save();

            DB::commit();

            return redirect()
                ->route('order.due_settlement', $order->id)
                ->with('success', 'Due payment of ৳' . number_format($amount, 2) . ' received successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();

            return back()->with('error', 'Due payment failed! ' . $e->getMessage())->withInput();
        }
    }

    public function details($id)
    {
        $order = Order::with(['customer', 'table', 'waiter', 'orderDetails', 'user', 'deliveryPartner', 'review'])->findOrFail($id);

        return view('admin.order.show', compact('order'));
    }


    public function deletedHistory($id)
    {
        $order = Order::with(['customer', 'table'])->findOrFail($id);

        $histories = PosDeletedItemHistory::with('user')
            ->where('order_id', $order->id)
            ->orderBy('id', 'desc')
            ->get();

        return view('admin.order.partials._delete_history', compact('order', 'histories'))->render();
    }

    public function destroy($id)
{
    if (!auth()->user()->can('order-delete')) {
        return response()->json([
            'status' => 'error',
            'message' => 'You do not have permission to delete this order.'
        ], 403);
    }

    \Illuminate\Support\Facades\DB::beginTransaction();

    try {
        $order = Order::with(['orderDetails', 'kots'])->findOrFail($id);

        // যদি dine-in order হয়, table available করে দেওয়া
        if ($order->table_id) {
            \App\Models\Table::where('id', $order->table_id)->update([
                'initial_status' => 'Available'
            ]);
        }

        // Related data delete
        \App\Models\OrderDetail::where('order_id', $order->id)->delete();
        \App\Models\OrderKot::where('order_id', $order->id)->delete();

        // Main order delete
        $order->delete();

        \Illuminate\Support\Facades\DB::commit();

        return response()->json([
            'status' => 'success',
            'message' => 'Order deleted successfully!'
        ]);

    } catch (\Exception $e) {
        \Illuminate\Support\Facades\DB::rollBack();

        return response()->json([
            'status' => 'error',
            'message' => 'Order delete failed! ' . $e->getMessage()
        ], 500);
    }
}
}
