<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Permission\Traits\HasRoles;
use Laravel\Sanctum\HasApiTokens;
class User extends Authenticatable
{
    use HasFactory, Notifiable, HasRoles, HasApiTokens;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'user_id',
        'first_name',
        'last_name',
        'email',
        'phone',
        'image',
        'last_login',
        'password',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'last_login' => 'datetime', // DateTime object hishebe pabar jonno
        ];
    }

    public function employee()
    {
        return $this->hasOne(Employee::class);
    }

    public function waiter()
    {
        return $this->hasOne(Waiter::class);
    }

    public function isInventoryManager(): bool
    {
        return $this->hasRole('Inventory Manager');
    }

    public function isKitchenUser(): bool
    {
        return $this->hasRole('Kitchen User');
    }


    /**
     * Check access for Offline POS Device Management.
     */
    public function isSuperAdmin(): bool
    {
        return $this->hasRole('Super Admin');
    }

    /**
     * Check access for Offline POS Device Management.
     */
    public function canManageOfflinePosDevices(): bool
    {
        return $this->isSuperAdmin() || $this->can('offline-pos-device-view');
    }

}
