<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PDFController;
use App\Http\Controllers\Admin\LoginController;
use App\Http\Controllers\Admin\CustomResetPasswordController; // নতুন কন্ট্রোলার
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Admin\PermissionController;
use App\Http\Controllers\Admin\RoleController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\ProfileController;
use App\Http\Controllers\Admin\SettingController;
use App\Http\Controllers\Admin\HrSettingController;
use App\Http\Controllers\Admin\HrDashboardController;
use App\Http\Controllers\Admin\EmployeeController;
use App\Http\Controllers\Admin\EmployeeSalaryController;
use App\Http\Controllers\Admin\AttendanceController;
use App\Http\Controllers\Admin\TipsoiController;
use App\Http\Controllers\Admin\LeaveManagementController;
use App\Http\Controllers\Admin\HrShiftController;
use App\Http\Controllers\Admin\PayrollController;
use App\Http\Controllers\Admin\SalaryAdvanceController;
use App\Http\Controllers\Admin\LoanController;
use App\Http\Controllers\Admin\ShiftController;
use App\Http\Controllers\Admin\WaiterController;
use App\Http\Controllers\Admin\CustomerController;
use App\Http\Controllers\Admin\RewardPointSettingController;
use App\Http\Controllers\Admin\TableController;
use App\Http\Controllers\Admin\TableBookingController;
use App\Http\Controllers\Admin\OccasionController;
use App\Http\Controllers\Admin\FoodCategoryController;
use App\Http\Controllers\Admin\DeliveryPartnerController;
Route::get('/', function () {
    return view('admin.auth.login');
});

Route::get('/clear', function() {
    \Illuminate\Support\Facades\Artisan::call('cache:clear');
    \Illuminate\Support\Facades\Artisan::call('config:clear');
    \Illuminate\Support\Facades\Artisan::call('config:cache');
    \Illuminate\Support\Facades\Artisan::call('view:clear');
    \Illuminate\Support\Facades\Artisan::call('route:clear');
    return redirect()->back();
});

// ডিফল্ট অথ রাউট (কিন্তু রিসেট রাউটগুলো ফলস করে দিলাম)
Auth::routes(['reset' => false]);

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/dashboard/chart-data', [App\Http\Controllers\HomeController::class, 'chartData'])->name('dashboard.chart_data');
Route::get('/dashboard/top-selling-items', [App\Http\Controllers\HomeController::class, 'topSellingItems'])->name('dashboard.top_selling_items');
Route::get('/dashboard/top-selling-items/pdf', [App\Http\Controllers\HomeController::class, 'downloadTopSellingItemsPdf'])->name('dashboard.top_selling_items.pdf');
Route::get('/dashboard/top-selling-items/excel', [App\Http\Controllers\HomeController::class, 'downloadTopSellingItemsExcel'])->name('dashboard.top_selling_items.excel');
Route::get('/download-pdf', [PDFController::class, 'generatePDF']);
Route::get('/admin/login', [LoginController::class, 'showLoginForm'])->name('admin.login');

// ==========================================
// Custom Password Reset Routes (GET & POST)
// ==========================================

// 1. Forgot Password Form & Send OTP
Route::get('/forgot-password', [CustomResetPasswordController::class, 'showForgotForm'])->name('password.request');
Route::post('/forgot-password', [CustomResetPasswordController::class, 'sendOtp'])->name('password.email');

// 2. OTP Verification Form & Verify Process
Route::get('/verify-otp', [CustomResetPasswordController::class, 'showOtpForm'])->name('password.otp');
Route::post('/verify-otp', [CustomResetPasswordController::class, 'verifyOtp'])->name('password.otp.verify');

// 3. Reset Password Form & Update Password
Route::get('/reset-password', [CustomResetPasswordController::class, 'showResetForm'])->name('password.resetForm');
Route::post('/reset-password', [CustomResetPasswordController::class, 'resetPassword'])->name('password.update');

Route::middleware(['auth'])->group(function () {

// Accounting V2.1 Phase 1 — single-company foundation, permission-gated.
Route::prefix('accounting')->name('accounting.')->group(function () {
    // Phase 5: only POSTED General Ledger contributes to official reports.
    Route::get('/financial-dashboard', fn() => redirect()->route('accounting.dashboard'))->name('financial-dashboard');
    Route::get('/financial-reports', [\App\Http\Controllers\Admin\Accounting\FinancialReports\FinancialReportsController::class,'index'])->name('reports');
    Route::get('/reports/balance-sheet', [\App\Http\Controllers\Admin\Accounting\FinancialReports\FinancialReportsController::class,'balanceSheet'])->name('reports.balance-sheet');
    Route::get('/reports/profit-loss', [\App\Http\Controllers\Admin\Accounting\FinancialReports\FinancialReportsController::class,'profitLoss'])->name('reports.profit-loss');
    Route::get('/reports/general-ledger', [\App\Http\Controllers\Admin\Accounting\FinancialReports\FinancialReportsController::class,'generalLedger'])->name('reports.general-ledger');
    Route::get('/reports/cash-flow', [\App\Http\Controllers\Admin\Accounting\FinancialReports\FinancialReportsController::class,'cashFlow'])->name('reports.cash-flow');
    Route::get('/reports/trial-balance', [\App\Http\Controllers\Admin\Accounting\FinancialReports\FinancialReportsController::class,'trialBalance'])->name('reports.trial-balance');
    Route::get('/reports/tax', [\App\Http\Controllers\Admin\Accounting\FinancialReports\FinancialReportsController::class,'taxActivity'])->name('reports.tax');
    Route::get('/reports/aging', [\App\Http\Controllers\Admin\Accounting\FinancialReports\FinancialReportsController::class,'agingReport'])->name('reports.aging');
    Route::get('/financial-reports/pdf', [\App\Http\Controllers\Admin\Accounting\FinancialReports\FinancialReportsController::class,'pdf'])->name('reports.pdf');
    Route::get('/financial-reports/export', [\App\Http\Controllers\Admin\Accounting\FinancialReports\FinancialReportsController::class,'export'])->name('reports.export');
    Route::get('/financial-report-rules', [\App\Http\Controllers\Admin\Accounting\ReportingRules\ReportingRulesController::class,'rules'])->name('report-rules');
    Route::post('/financial-report-rules', [\App\Http\Controllers\Admin\Accounting\ReportingRules\ReportingRulesController::class,'saveRules'])->name('report-rules.save');
    Route::get('/opening-cutover', [\App\Http\Controllers\Admin\Accounting\OpeningBalances\OpeningBalancesController::class,'cutover'])->name('cutover');
    Route::post('/opening-cutover', [\App\Http\Controllers\Admin\Accounting\OpeningBalances\OpeningBalancesController::class,'prepareCutover'])->name('cutover.prepare');
    Route::post('/opening-cutover/{id}/items', [\App\Http\Controllers\Admin\Accounting\OpeningBalances\OpeningBalancesController::class,'addOpeningItem'])->whereNumber('id')->name('cutover.items');
    Route::post('/opening-items/{itemId}/allocate', [\App\Http\Controllers\Admin\Accounting\OpeningBalances\OpeningBalancesController::class,'allocateOpening'])->whereNumber('itemId')->name('cutover.allocate');
    Route::post('/opening-cutover/{id}/approve', [\App\Http\Controllers\Admin\Accounting\OpeningBalances\OpeningBalancesController::class,'approveCutover'])->whereNumber('id')->name('cutover.approve');
    Route::get('/budgets', [\App\Http\Controllers\Admin\Accounting\Budgets\BudgetsController::class,'budgets'])->name('budgets');
    Route::post('/budgets', [\App\Http\Controllers\Admin\Accounting\Budgets\BudgetsController::class,'createBudget'])->name('budgets.create');
    Route::post('/budgets/{id}/lines', [\App\Http\Controllers\Admin\Accounting\Budgets\BudgetsController::class,'saveBudgetLine'])->whereNumber('id')->name('budgets.lines');
    Route::post('/budgets/{id}/approve', [\App\Http\Controllers\Admin\Accounting\Budgets\BudgetsController::class,'approveBudget'])->whereNumber('id')->name('budgets.approve');
    Route::get('/closing-review', [\App\Http\Controllers\Admin\Accounting\PeriodClosing\PeriodClosingController::class,'closingReview'])->name('closing');
    Route::post('/closing-review/year/{yearId}/draft', [\App\Http\Controllers\Admin\Accounting\PeriodClosing\PeriodClosingController::class,'yearEnd'])->whereNumber('yearId')->name('closing.year-draft');
    Route::post('/closing-review/year/{yearId}/refresh', [\App\Http\Controllers\Admin\Accounting\PeriodClosing\PeriodClosingController::class,'refreshYearEnd'])->whereNumber('yearId')->name('closing.year-refresh');
    Route::post('/closing-review/year/{yearId}/finish', [\App\Http\Controllers\Admin\Accounting\PeriodClosing\PeriodClosingController::class,'finishYear'])->whereNumber('yearId')->name('closing.year-finish');

    Route::get('/', [\App\Http\Controllers\Admin\Accounting\FinancialDashboard\FinancialDashboardController::class,'dashboard'])->name('dashboard');
    // Phase 4 — Extended Ledger. Mutations are permission-gated in controllers.
    Route::get('/payroll-ledger', [\App\Http\Controllers\Admin\Accounting\Payroll\PayrollAccountingController::class,'payroll'])->name('payroll');
    Route::post('/payroll-ledger/funding', [\App\Http\Controllers\Admin\Accounting\Payroll\PayrollAccountingController::class,'verifyFunding'])->name('payroll.funding');
    Route::post('/payroll-ledger/repayment', [\App\Http\Controllers\Admin\Accounting\Payroll\PayrollAccountingController::class,'verifyRepayment'])->name('payroll.repayment');
    Route::get('/due-terms', [\App\Http\Controllers\Admin\Accounting\PaymentTerms\PaymentTermsController::class,'dueTerms'])->name('due-terms');
    Route::post('/due-terms', [\App\Http\Controllers\Admin\Accounting\PaymentTerms\PaymentTermsController::class,'saveTerms'])->name('due-terms.save');
    Route::post('/due-terms/followups', [\App\Http\Controllers\Admin\Accounting\PaymentTerms\PaymentTermsController::class,'followup'])->name('due-terms.followup');
    Route::get('/cost-centers', [\App\Http\Controllers\Admin\Accounting\CostCenters\CostCentersController::class,'costCenters'])->name('cost-centers');
    Route::post('/cost-centers', [\App\Http\Controllers\Admin\Accounting\CostCenters\CostCentersController::class,'saveCenter'])->name('cost-centers.save');
    Route::post('/cost-centers/allocate', [\App\Http\Controllers\Admin\Accounting\CostCenters\CostCentersController::class,'allocate'])->name('cost-centers.allocate');
    Route::get('/bank-matching', [\App\Http\Controllers\Admin\Accounting\BankReconciliation\BankReconciliationController::class,'bank'])->name('bank');
    Route::post('/bank-matching', [\App\Http\Controllers\Admin\Accounting\BankReconciliation\BankReconciliationController::class,'saveBankLine'])->name('bank.save');
    Route::post('/bank-matching/{id}/match', [\App\Http\Controllers\Admin\Accounting\BankReconciliation\BankReconciliationController::class,'matchBank'])->whereNumber('id')->name('bank.match');
    Route::post('/bank-matching/{id}/unmatch', [\App\Http\Controllers\Admin\Accounting\BankReconciliation\BankReconciliationController::class,'unmatchBank'])->whereNumber('id')->name('bank.unmatch');
    Route::get('/deferrals', [\App\Http\Controllers\Admin\Accounting\Deferrals\DeferralsController::class,'deferrals'])->name('deferrals');
    Route::post('/deferrals', [\App\Http\Controllers\Admin\Accounting\Deferrals\DeferralsController::class,'createDeferral'])->name('deferrals.save');
    Route::post('/deferrals/lines/{id}/generate', [\App\Http\Controllers\Admin\Accounting\Deferrals\DeferralsController::class,'generateDeferral'])->whereNumber('id')->name('deferrals.generate');
    Route::get('/assets', [\App\Http\Controllers\Admin\Accounting\FixedAssets\FixedAssetsController::class,'assets'])->name('assets');
    Route::post('/assets/policy', [\App\Http\Controllers\Admin\Accounting\FixedAssets\FixedAssetsController::class,'approveAssetPolicy'])->name('assets.policy');
    Route::post('/assets', [\App\Http\Controllers\Admin\Accounting\FixedAssets\FixedAssetsController::class,'addAsset'])->name('assets.save');
    Route::post('/assets/{id}/dispose', [\App\Http\Controllers\Admin\Accounting\FixedAssets\FixedAssetsController::class,'dispose'])->whereNumber('id')->name('assets.dispose');
    Route::post('/assets/{id}/dispose-cancel', [\App\Http\Controllers\Admin\Accounting\FixedAssets\FixedAssetsController::class,'cancelDisposal'])->whereNumber('id')->name('assets.dispose-cancel');
    Route::post('/assets/{id}/depreciate', [\App\Http\Controllers\Admin\Accounting\FixedAssets\FixedAssetsController::class,'depreciation'])->whereNumber('id')->name('assets.depreciate');
    Route::get('/financial-details/export/pdf', [\App\Http\Controllers\Admin\Accounting\FinancialDetailsController::class,'pdf'])->name('financial-details.pdf');
    Route::get('/financial-details/export/excel', [\App\Http\Controllers\Admin\Accounting\FinancialDetailsController::class,'excel'])->name('financial-details.excel');
    Route::get('/financial-details', [\App\Http\Controllers\Admin\Accounting\FinancialDetailsController::class,'index'])->name('financial-details');
    Route::get('/company-loans', [\App\Http\Controllers\Admin\Accounting\CompanyLoans\CompanyLoansController::class,'loans'])->name('loans');
    Route::post('/company-loans', [\App\Http\Controllers\Admin\Accounting\CompanyLoans\CompanyLoansController::class,'createLoan'])->name('loans.save');
    Route::post('/company-loans/installments/{id}/adjust', [\App\Http\Controllers\Admin\Accounting\CompanyLoans\CompanyLoansController::class,'adjustInstallment'])->whereNumber('id')->name('loans.installment-adjust');
    Route::post('/company-loans/{id}/schedule', [\App\Http\Controllers\Admin\Accounting\CompanyLoans\CompanyLoansController::class,'schedule'])->whereNumber('id')->name('loans.schedule');
    Route::post('/company-loans/{id}/repay', [\App\Http\Controllers\Admin\Accounting\CompanyLoans\CompanyLoansController::class,'repayLoan'])->whereNumber('id')->name('loans.repay');

    // Phase 2: receipts, POS clearing, cash reconciliation; Phase 3: expenses, costs, supplier tax.
    Route::get('/credit-notes', [\App\Http\Controllers\Admin\Accounting\CreditNotes\CreditNotesController::class,'index'])->name('credits');
    Route::post('/credit-notes/sales', [\App\Http\Controllers\Admin\Accounting\CreditNotes\CreditNotesController::class,'sale'])->name('credits.sales');
    Route::post('/credit-notes/deposits', [\App\Http\Controllers\Admin\Accounting\CreditNotes\CreditNotesController::class,'booking'])->name('credits.booking');
    Route::post('/credit-notes/suppliers', [\App\Http\Controllers\Admin\Accounting\CreditNotes\CreditNotesController::class,'supplier'])->name('credits.supplier');
    Route::get('/vouchers', [\App\Http\Controllers\Admin\Accounting\Vouchers\VouchersController::class,'vouchers'])->name('vouchers');
    Route::post('/vouchers', [\App\Http\Controllers\Admin\Accounting\Vouchers\VouchersController::class,'storeVoucher'])->name('vouchers.store');
    Route::post('/expenses/{id}/attachment', [\App\Http\Controllers\Admin\Accounting\Expenses\ExpensesController::class,'attachExpense'])->whereNumber('id')->name('expenses.attach');
    Route::get('/expense-attachments/{id}', [\App\Http\Controllers\Admin\Accounting\Expenses\ExpensesController::class,'downloadExpenseAttachment'])->whereNumber('id')->name('expenses.attachment');
    Route::post('/cash-reconciliations/{id}/approve', [\App\Http\Controllers\Admin\Accounting\CashReconciliation\CashReconciliationController::class,'approveSession'])->whereNumber('id')->name('sessions.approve');
    Route::get('/expenses', [\App\Http\Controllers\Admin\Accounting\Expenses\ExpensesController::class,'expenses'])->name('expenses');
    Route::post('/expenses', [\App\Http\Controllers\Admin\Accounting\Expenses\ExpensesController::class,'storeExpense'])->name('expenses.store');
    Route::post('/expenses/{id}/approve', [\App\Http\Controllers\Admin\Accounting\Expenses\ExpensesController::class,'approveExpense'])->whereNumber('id')->name('expenses.approve');
    Route::get('/inventory-cost', [\App\Http\Controllers\Admin\Accounting\InventoryCost\InventoryCostController::class,'costs'])->name('costs');
    Route::post('/inventory-cost/{id}/verify', [\App\Http\Controllers\Admin\Accounting\InventoryCost\InventoryCostController::class,'verifyCost'])->whereNumber('id')->name('costs.verify');
    Route::get('/payment-clearing', [\App\Http\Controllers\Admin\Accounting\PaymentClearing\PaymentClearingController::class,'clearing'])->name('clearing');
    Route::post('/payment-clearing/{transactionId}/settle', [\App\Http\Controllers\Admin\Accounting\PaymentClearing\PaymentClearingController::class,'settle'])->whereNumber('transactionId')->name('clearing.settle');
    Route::get('/withholdings', [\App\Http\Controllers\Admin\Accounting\WithholdingTax\WithholdingTaxController::class,'withholdings'])->name('withholdings');
    Route::post('/withholdings', [\App\Http\Controllers\Admin\Accounting\WithholdingTax\WithholdingTaxController::class,'storeWithholding'])->name('withholdings.store');
    Route::get('/cash-reconciliations', [\App\Http\Controllers\Admin\Accounting\CashReconciliation\CashReconciliationController::class,'sessions'])->name('sessions');
    Route::post('/cash-reconciliations/{id}', [\App\Http\Controllers\Admin\Accounting\CashReconciliation\CashReconciliationController::class,'reconcileSession'])->whereNumber('id')->name('sessions.reconcile');
    Route::get('/settings', [\App\Http\Controllers\Admin\Accounting\Settings\AccountingSettingsController::class,'settings'])->name('settings');
    Route::post('/settings', [\App\Http\Controllers\Admin\Accounting\Settings\AccountingSettingsController::class,'saveSettings'])->name('settings.save');
    Route::get('/chart-of-accounts', [\App\Http\Controllers\Admin\Accounting\ChartOfAccounts\ChartOfAccountsController::class,'accounts'])->name('accounts');
    Route::post('/chart-of-accounts', [\App\Http\Controllers\Admin\Accounting\ChartOfAccounts\ChartOfAccountsController::class,'saveAccount'])->name('accounts.save');
    Route::get('/fiscal-periods', [\App\Http\Controllers\Admin\Accounting\FiscalPeriods\FiscalPeriodsController::class,'periods'])->name('periods');
    Route::post('/fiscal-periods/years', [\App\Http\Controllers\Admin\Accounting\FiscalPeriods\FiscalPeriodsController::class,'createYear'])->name('periods.year');
    Route::post('/fiscal-periods/{id}/status', [\App\Http\Controllers\Admin\Accounting\FiscalPeriods\FiscalPeriodsController::class,'changePeriod'])->whereNumber('id')->name('periods.change');
    Route::get('/journal-types', [\App\Http\Controllers\Admin\Accounting\JournalTypes\JournalTypesController::class,'journalTypes'])->name('journal-types');
    Route::post('/journal-types', [\App\Http\Controllers\Admin\Accounting\JournalTypes\JournalTypesController::class,'saveJournalType'])->name('journal-types.save');
    Route::get('/audit-log', [\App\Http\Controllers\Admin\Accounting\AuditLog\AccountingAuditController::class,'audit'])->name('audit');
    Route::get('/mappings', [\App\Http\Controllers\Admin\Accounting\AccountMappings\AccountMappingsController::class,'mappings'])->name('mappings');
    Route::post('/mappings', [\App\Http\Controllers\Admin\Accounting\AccountMappings\AccountMappingsController::class,'saveMapping'])->name('mappings.save');
    Route::get('/pending-events', [\App\Http\Controllers\Admin\Accounting\PendingEvents\PendingEventsController::class,'events'])->name('events');
    Route::post('/pending-events/{id}/generate-post', [\App\Http\Controllers\Admin\Accounting\PendingEvents\PendingEventsController::class,'generatePost'])->whereNumber('id')->name('events.generate-post');
    Route::post('/pending-events/{id}/generate', [\App\Http\Controllers\Admin\Accounting\PendingEvents\PendingEventsController::class,'generate'])->whereNumber('id')->name('events.generate');
    Route::post('/pending-events/bulk-generate', [\App\Http\Controllers\Admin\Accounting\PendingEvents\PendingEventsController::class,'bulkGenerate'])->name('events.bulk-generate');
    // Safe deletes are limited to unused master data and unposted drafts; immutable GL has no delete endpoint.
    Route::delete('/chart-of-accounts/{id}', [\App\Http\Controllers\Admin\Accounting\ChartOfAccounts\ChartOfAccountsController::class,'deleteAccount'])->whereNumber('id')->name('accounts.delete');
    Route::delete('/journal-types/{id}', [\App\Http\Controllers\Admin\Accounting\JournalTypes\JournalTypesController::class,'deleteJournalType'])->whereNumber('id')->name('journal-types.delete');
    Route::patch('/journal-types/{id}/deactivate', [\App\Http\Controllers\Admin\Accounting\JournalTypes\JournalTypesController::class,'deactivateJournalType'])->whereNumber('id')->name('journal-types.deactivate');
    Route::delete('/mappings/{id}', [\App\Http\Controllers\Admin\Accounting\AccountMappings\AccountMappingsController::class,'deleteMapping'])->whereNumber('id')->name('mappings.delete');
    Route::delete('/cost-centers/{id}', [\App\Http\Controllers\Admin\Accounting\CostCenters\CostCentersController::class,'deleteCenter'])->whereNumber('id')->name('cost-centers.delete');
    Route::delete('/expenses/{id}', [\App\Http\Controllers\Admin\Accounting\Expenses\ExpensesController::class,'deleteExpense'])->whereNumber('id')->name('expenses.delete');
    Route::delete('/budgets/{id}', [\App\Http\Controllers\Admin\Accounting\Budgets\BudgetsController::class,'deleteBudget'])->whereNumber('id')->name('budgets.delete');
    Route::delete('/bank-matching/{id}', [\App\Http\Controllers\Admin\Accounting\BankReconciliation\BankReconciliationController::class,'deleteBankLine'])->whereNumber('id')->name('bank.delete');
    Route::delete('/journals/{id}', [\App\Http\Controllers\Admin\Accounting\Journals\JournalsController::class,'deleteDraft'])->whereNumber('id')->name('journals.delete');

    Route::get('/trial-balance', [\App\Http\Controllers\Admin\Accounting\TrialBalance\TrialBalanceController::class,'trialBalance'])->name('trial-balance');
    Route::get('/journals', [\App\Http\Controllers\Admin\Accounting\Journals\JournalsController::class,'index'])->name('journals.index');
    Route::get('/journals/create', [\App\Http\Controllers\Admin\Accounting\Journals\JournalsController::class,'create'])->name('journals.create');
    Route::post('/journals', [\App\Http\Controllers\Admin\Accounting\Journals\JournalsController::class,'store'])->name('journals.store');
    Route::get('/journals/{id}', [\App\Http\Controllers\Admin\Accounting\Journals\JournalsController::class,'show'])->whereNumber('id')->name('journals.show');
    Route::get('/journals/{id}/edit', [\App\Http\Controllers\Admin\Accounting\Journals\JournalsController::class,'edit'])->whereNumber('id')->name('journals.edit');
    Route::put('/journals/{id}', [\App\Http\Controllers\Admin\Accounting\Journals\JournalsController::class,'update'])->whereNumber('id')->name('journals.update');
    Route::post('/journals/{id}/action', [\App\Http\Controllers\Admin\Accounting\Journals\JournalsController::class,'action'])->whereNumber('id')->name('journals.action');
    Route::post('/journals/{id}/attachment', [\App\Http\Controllers\Admin\Accounting\Journals\JournalsController::class,'upload'])->whereNumber('id')->name('journals.upload');
    Route::get('/attachments/{id}/download', [\App\Http\Controllers\Admin\Accounting\Journals\JournalsController::class,'attachment'])->whereNumber('id')->name('journals.attachment');
});


// Refresh CSRF token for long-open AJAX pages like Kitchen Board
Route::get('/refresh-csrf-token', function () {
    return response()->json(['csrf_token' => csrf_token()]);
})->name('csrf.refresh');



// ==========================================
    // Real-Time Notifications (QR Orders & Waiter Calls)
    // ==========================================
    Route::get('/notifications-check', [App\Http\Controllers\Admin\OrderController::class, 'checkNotifications'])->name('notifications.check');
    Route::post('/notifications-accept-order', [App\Http\Controllers\Admin\OrderController::class, 'acceptQrOrder'])->name('notifications.accept_order');
    Route::post('/notifications-resolve-waiter', [App\Http\Controllers\Admin\OrderController::class, 'resolveWaiterCall'])->name('notifications.resolve_waiter');

// ==========================================
    // Table QR Code Builder Routes
    // ==========================================
    Route::get('/qr-code-builder', [App\Http\Controllers\Admin\QrCodeController::class, 'index'])->name('qrcode.index');
    Route::get('/qr-code-builder/get-tables/{zone_id}', [App\Http\Controllers\Admin\QrCodeController::class, 'getTables'])->name('qrcode.get_tables');
    Route::post('/qr-code-builder/generate-pdf', [App\Http\Controllers\Admin\QrCodeController::class, 'generatePdf'])->name('qrcode.generate_pdf');
// ==========================================
    // Reports & Analytics Routes
    // ==========================================
    Route::get('reports', [App\Http\Controllers\Admin\ReportController::class, 'salesOrder'])->name('reports.index');
    Route::get('reports/sales-order', [App\Http\Controllers\Admin\ReportController::class, 'salesOrder'])->name('reports.sales_order');
    Route::get('reports/delivery', [App\Http\Controllers\Admin\ReportController::class, 'deliveryReport'])->name('reports.delivery');
    Route::get('reports/due', [App\Http\Controllers\Admin\ReportController::class, 'dueReport'])->name('reports.due');
    Route::get('reports/due/pdf', [App\Http\Controllers\Admin\ReportController::class, 'dueReportPdf'])->name('reports.due.pdf');
    Route::get('reports/due/excel', [App\Http\Controllers\Admin\ReportController::class, 'dueReportExcel'])->name('reports.due.excel');
    Route::get('reports/delivery/pdf', [App\Http\Controllers\Admin\ReportController::class, 'deliveryReportPdf'])->name('reports.delivery.pdf');
    Route::get('reports/delivery/excel', [App\Http\Controllers\Admin\ReportController::class, 'deliveryReportExcel'])->name('reports.delivery.excel');
    Route::get('reports/complimentary-orders', [App\Http\Controllers\Admin\ReportController::class, 'complimentaryOrders'])->name('reports.complimentary_orders');
    Route::get('reports/payment-type-wise-sales', [App\Http\Controllers\Admin\ReportController::class, 'paymentTypeSales'])->name('reports.payment_type_sales');
    Route::get('reports/food-wise-sales', [App\Http\Controllers\Admin\ReportController::class, 'foodSales'])->name('reports.food_sales');
    Route::get('reports/waiter-daily-orders', [App\Http\Controllers\Admin\ReportController::class, 'waiterDailyOrders'])->name('reports.waiter_daily_orders');
    Route::get('reports/waiter-daily-orders/pdf', [App\Http\Controllers\Admin\ReportController::class, 'waiterDailyOrdersPdf'])->name('reports.waiter_daily_orders.pdf');
    Route::get('reports/waiter-daily-orders/excel', [App\Http\Controllers\Admin\ReportController::class, 'waiterDailyOrdersExcel'])->name('reports.waiter_daily_orders.excel');
    Route::get('reports/kots', [App\Http\Controllers\Admin\ReportController::class, 'kotReport'])->name('reports.kots');
    Route::get('reports/kots/pdf', [App\Http\Controllers\Admin\ReportController::class, 'kotReportPdf'])->name('reports.kots.pdf');
    Route::get('reports/kots/excel', [App\Http\Controllers\Admin\ReportController::class, 'kotReportExcel'])->name('reports.kots.excel');
    Route::get('reports/pos-sessions', [App\Http\Controllers\Admin\ReportController::class, 'posSessionReport'])->name('reports.pos_sessions');
    Route::get('reports/pos-sessions/combined-print', [App\Http\Controllers\Admin\ReportController::class, 'posSessionCombinedPrint'])->name('reports.pos_sessions.combined_print');
    Route::get('reports/pos-sessions/pdf', [App\Http\Controllers\Admin\ReportController::class, 'posSessionReportPdf'])->name('reports.pos_sessions.pdf');
    Route::get('reports/pos-sessions/excel', [App\Http\Controllers\Admin\ReportController::class, 'posSessionReportExcel'])->name('reports.pos_sessions.excel');
    Route::get('reports/export/pdf', [App\Http\Controllers\Admin\ReportController::class, 'exportPdf'])->name('reports.export.pdf');
    Route::get('reports/export/excel', [App\Http\Controllers\Admin\ReportController::class, 'exportExcel'])->name('reports.export.excel');
    Route::get('reports/export/csv', [App\Http\Controllers\Admin\ReportController::class, 'exportCsv'])->name('reports.export.csv');

// ==========================================
 // ==========================================
    // Food Category AJAX
    // ==========================================
    Route::get('get-subcategories/{id}', [App\Http\Controllers\Admin\FoodCategoryController::class, 'getSubcategories']);
// POS Session Routes
Route::post('pos-session-start', [App\Http\Controllers\Admin\PosController::class, 'startSession'])->name('pos.session.start');
Route::post('pos-session-end', [App\Http\Controllers\Admin\PosController::class, 'endSession'])->name('pos.session.end');
Route::post('pos-session-activity', [App\Http\Controllers\Admin\PosController::class, 'touchSessionActivity'])->name('pos.session.activity');
Route::get('pos-session-status', [App\Http\Controllers\Admin\PosController::class, 'sessionStatus'])->name('pos.session.status');
Route::get('pos-session-history', [App\Http\Controllers\Admin\PosController::class, 'sessionHistory'])->name('pos.session.history');

// POS Session History & Report Routes
Route::get('/pos/session/report/{id}', [App\Http\Controllers\Admin\PosController::class, 'printSessionReport'])->name('pos.session.report');
Route::post('/pos/session/update', [App\Http\Controllers\Admin\PosController::class, 'updateSession'])->name('pos.session.update');

Route::post('/kitchen/mark-unavailable', [App\Http\Controllers\Admin\KitchenController::class, 'markItemUnavailable'])->name('kitchen.mark_unavailable');
    // ==========================================
    // POS (Point of Sale) Routes
    // ==========================================
    Route::get('/pos', [App\Http\Controllers\Admin\PosController::class, 'index'])->name('pos.index');
    Route::get('/pos/sessions', [App\Http\Controllers\Admin\PosController::class, 'sessionList'])->name('pos.sessions.index');
    Route::get('/pos/sessions/pdf', [App\Http\Controllers\Admin\PosController::class, 'sessionListPdf'])->name('pos.sessions.pdf');
    Route::get('/pos/sessions/excel', [App\Http\Controllers\Admin\PosController::class, 'sessionListExcel'])->name('pos.sessions.excel');
    Route::get('/pos/kots', [App\Http\Controllers\Admin\PosController::class, 'kotList'])->name('pos.kots.index');
    Route::get('/pos/kots/pdf', [App\Http\Controllers\Admin\PosController::class, 'kotListPdf'])->name('pos.kots.pdf');
    Route::get('/pos/kots/excel', [App\Http\Controllers\Admin\PosController::class, 'kotListExcel'])->name('pos.kots.excel');
    Route::post('/pos/random-half-order/activate', [App\Http\Controllers\Admin\PosController::class, 'activateRandomHalfOrderList'])->name('pos.random_half_order.activate');

    // POS: Food & Category
    Route::get('/pos/foods', [App\Http\Controllers\Admin\PosController::class, 'getFoods'])->name('pos.get_foods');
    Route::get('/pos/get-addons/{id}', [App\Http\Controllers\Admin\PosController::class, 'getAddons'])->name('pos.get_addons');

    // POS: Customer
    Route::get('/pos/search-customer', [App\Http\Controllers\Admin\PosController::class, 'searchCustomer'])->name('pos.search_customer');
    Route::post('/pos/store-customer', [App\Http\Controllers\Admin\PosController::class, 'storeCustomer'])->name('pos.store_customer');

    // POS: Cart Management (AJAX)
    Route::get('/pos/cart', [App\Http\Controllers\Admin\PosController::class, 'getCart'])->name('pos.cart.get');
    Route::post('/pos/cart/add', [App\Http\Controllers\Admin\PosController::class, 'addToCart'])->name('pos.cart.add');
    Route::post('/pos/cart/update', [App\Http\Controllers\Admin\PosController::class, 'updateCart'])->name('pos.cart.update');
    Route::post('/pos/cart/remove', [App\Http\Controllers\Admin\PosController::class, 'removeFromCart'])->name('pos.cart.remove');
    Route::post('/pos/action/verify', [App\Http\Controllers\Admin\PosController::class, 'verifyPosActionPassword'])->name('pos.action.verify');
    Route::post('/pos/order-item/remove', [App\Http\Controllers\Admin\PosController::class, 'removeOrderedItem'])->name('pos.order_item.remove');
    Route::post('/pos/order-item/complimentary', [App\Http\Controllers\Admin\PosController::class, 'makeOrderedItemComplimentary'])->name('pos.order_item.complimentary');
    Route::post('/pos/cart/clear', [App\Http\Controllers\Admin\PosController::class, 'clearCart'])->name('pos.cart.clear');
Route::get('reviews', [App\Http\Controllers\Admin\ReviewController::class, 'index'])->name('reviews.index');
    // POS: Order & Payment
    Route::post('/pos-cart-update-note', [App\Http\Controllers\Admin\PosController::class, 'updateNote'])->name('pos.cart.update_note');
    Route::post('/pos-place-order', [App\Http\Controllers\Admin\PosController::class, 'placeOrder'])->name('pos.place_order'); // Send to Kitchen
    Route::post('/pos/hold-web-order', [App\Http\Controllers\Admin\PosController::class, 'holdWebOrder'])->name('pos.hold_web_order'); // Hold website QR order in POS cart
    Route::get('/pos/table-order/{table_id}', [App\Http\Controllers\Admin\PosController::class, 'getTableOrder'])->name('pos.get_table_order'); // Occupied Table Data
    Route::get('/pos/table-reservation-statuses', [App\Http\Controllers\Admin\PosController::class, 'tableReservationStatuses'])->name('pos.table_reservation_statuses'); // Live BD-time reservation state
    Route::post('/pos/table-swap', [App\Http\Controllers\Admin\PosController::class, 'swapTable'])->name('pos.table_swap'); // Dine-In active order table swap
    Route::post('/pos/active-order/update-meta', [App\Http\Controllers\Admin\PosController::class, 'updateActiveOrderMeta'])->name('pos.active_order.update_meta'); // Customer / delivery partner update before payment
    Route::get('/pos/active-order/{order_id}', [App\Http\Controllers\Admin\PosController::class, 'getPosOrder'])->name('pos.get_pos_order'); // Takeaway/Delivery active order data
    Route::post('/pos/takeaway-delivery/complete-pending', [App\Http\Controllers\Admin\PosController::class, 'completePendingTakeawayDeliveryPayments'])->name('pos.takeaway_delivery.complete_pending');
    Route::post('/pos/payment', [App\Http\Controllers\Admin\PosController::class, 'completePayment'])->name('pos.complete_payment');
Route::get('orders/{id}/details', [App\Http\Controllers\Admin\OrderController::class, 'details'])->name('order.details');
Route::get('/pos/invoice/{id}', [App\Http\Controllers\Admin\PosController::class, 'printInvoice'])->name('pos.invoice');
// Pre-payment invoice (Guest Bill)
    Route::post('/pos/pre-invoice/{id}/snapshot', [App\Http\Controllers\Admin\PosController::class, 'savePreInvoiceSnapshot'])->name('pos.pre_invoice.snapshot');
    Route::get('/pos/pre-invoice/{id}', [App\Http\Controllers\Admin\PosController::class, 'printPreInvoice'])->name('pos.pre_invoice');
   // ==========================================
    // Kitchen (KOT) Routes
    // ==========================================
    Route::get('/kitchen', [App\Http\Controllers\Admin\KitchenController::class, 'index'])->name('kitchen.index');
    Route::get('/kitchen/get-live-orders', [App\Http\Controllers\Admin\KitchenController::class, 'getLiveOrders'])->name('kitchen.get_live_orders');
    Route::post('/kitchen/update-status', [App\Http\Controllers\Admin\KitchenController::class, 'updateStatus'])->name('kitchen.update_status');

    // KOT প্রিন্ট করার জন্য নতুন রাউট
    Route::get('/kitchen/print-kot/{id}', [App\Http\Controllers\Admin\KitchenController::class, 'printKot'])->name('kitchen.print_kot');
    Route::get('/kitchen/print-order-kot/{id}', [App\Http\Controllers\Admin\KitchenController::class, 'printMergedOrderKot'])->name('kitchen.print_order_kot');

Route::get('get-subcategories/{id}', [App\Http\Controllers\Admin\FoodCategoryController::class, 'getSubcategories']);
// Food Item Routes
    Route::resource('food-item', App\Http\Controllers\Admin\FoodItemController::class);
    Route::post('food-item-status/{id}', [App\Http\Controllers\Admin\FoodItemController::class, 'updateStatus'])->name('food-item.status');
// Allergen Routes
    Route::resource('allergen', App\Http\Controllers\Admin\AllergenController::class);
    Route::post('allergen-status/{id}', [App\Http\Controllers\Admin\AllergenController::class, 'updateStatus'])->name('allergen.status');

    // Course Type Routes
    Route::resource('course-type', App\Http\Controllers\Admin\CourseTypeController::class);
    Route::post('course-type-status/{id}', [App\Http\Controllers\Admin\CourseTypeController::class, 'updateStatus'])->name('course-type.status');
Route::get('orders-export-pdf', [App\Http\Controllers\Admin\OrderController::class, 'exportPDF'])->name('order.export_pdf');
Route::get('due-orders-export-pdf', [App\Http\Controllers\Admin\OrderController::class, 'exportPDF'])->name('due_orders.export_pdf');
Route::get('due-orders-export-excel', [App\Http\Controllers\Admin\OrderController::class, 'exportExcel'])->name('due_orders.export_excel');
Route::get('orders-export-excel', [App\Http\Controllers\Admin\OrderController::class, 'exportExcel'])->name('order.export_excel');
Route::get('orders-print', [App\Http\Controllers\Admin\OrderController::class, 'printReport'])->name('order.print_report');

    Route::resource('delivery-partner', DeliveryPartnerController::class);

// Food Category Routes
    Route::resource('food-category', FoodCategoryController::class);
Route::post('food-category-status/{id}', [FoodCategoryController::class, 'updateStatus'])->name('food-category.status');

// ==========================================
    // Order Management Routes
    // ==========================================
    Route::get('orders', [App\Http\Controllers\Admin\OrderController::class, 'index'])->name('order.index');
    Route::get('orders/due-list', [App\Http\Controllers\Admin\OrderController::class, 'dueList'])->name('order.due_list');
    // Order edit page: existing quantity/payment summary and complimentary conversion can be changed.
    Route::get('orders/{id}/edit', [App\Http\Controllers\Admin\OrderController::class, 'edit'])->name('order.edit');
    Route::put('orders/{id}', [App\Http\Controllers\Admin\OrderController::class, 'update'])->name('order.update');
    Route::post('orders/{id}/pay-due', [App\Http\Controllers\Admin\OrderController::class, 'payDue'])->name('order.pay_due');
    Route::get('orders/{id}/due-settlement', [App\Http\Controllers\Admin\OrderController::class, 'dueSettlement'])->name('order.due_settlement');
    Route::get('orders/{id}', [App\Http\Controllers\Admin\OrderController::class, 'show'])->name('order.show');
    Route::get('orders/{id}/delete-history', [App\Http\Controllers\Admin\OrderController::class, 'deletedHistory'])->name('order.delete_history');
    Route::delete('orders/{id}', [App\Http\Controllers\Admin\OrderController::class, 'destroy'])
    ->name('order.destroy');
// Cuisine Type Routes
    Route::resource('cuisine-type', App\Http\Controllers\Admin\CuisineTypeController::class);
    Route::post('cuisine-type-status/{id}', [App\Http\Controllers\Admin\CuisineTypeController::class, 'updateStatus'])->name('cuisine-type.status');
// ==========================================
    // Table Booking Routes
    // ==========================================
    Route::resource('table-booking', TableBookingController::class);
    Route::post('table-booking/create-customer-ajax', [TableBookingController::class, 'createCustomerAjax'])->name('table-booking.create-customer-ajax');

    // ==========================================
    // Occasion Management Routes (AJAX Based)
    // ==========================================
    Route::get('occasion', [OccasionController::class, 'index'])->name('occasion.index');
    Route::post('occasion', [OccasionController::class, 'store'])->name('occasion.store');
    Route::put('occasion/{id}', [OccasionController::class, 'update'])->name('occasion.update');
    Route::delete('occasion/{id}', [OccasionController::class, 'destroy'])->name('occasion.destroy');

// ==========================================
    // Table Management Routes
    // ==========================================
    Route::resource('table', TableController::class);
    Route::post('table/floor-zone', [App\Http\Controllers\Admin\TableController::class, 'storeFloorZone'])->name('table.floor_zone.store');
    Route::put('table/floor-zone/{id}', [App\Http\Controllers\Admin\TableController::class, 'updateFloorZone'])->name('table.floor_zone.update');
    Route::delete('table/floor-zone/{id}', [App\Http\Controllers\Admin\TableController::class, 'destroyFloorZone'])->name('table.floor_zone.destroy');


// ==========================================
    // Customer Management Routes
    // ==========================================

    // Customer Export Routes
Route::get('customer-export-pdf', [CustomerController::class, 'exportPDF'])->name('customer.export.pdf');
Route::get('customer-export-excel', [CustomerController::class, 'exportExcel'])->name('customer.export.excel');


    Route::resource('customer', CustomerController::class);
// Customer History Route (Ajax)
    Route::get('customer-history/{id}', [CustomerController::class, 'history'])->name('customer.history');
    // ==========================================
    // Reward Point Settings Routes
    // ==========================================
    Route::get('reward-points', [RewardPointSettingController::class, 'index'])->name('reward-points.index');
    Route::post('reward-points/update', [RewardPointSettingController::class, 'update'])->name('reward-points.update');


// Table Management owns the single Floor / Zone module.
    Route::resource('floor-zone', App\Http\Controllers\Admin\FloorZoneController::class);

    // Shift Management Routes
    Route::resource('shift', ShiftController::class);
Route::post('waiter-update-status', [WaiterController::class, 'updateStatus'])->name('waiter.status');
    Route::post('waiter-link-user', [WaiterController::class, 'linkUser'])->name('waiter.link_user');
    // Waiter Management Routes
    Route::resource('waiter', WaiterController::class);


    Route::resource('permission', PermissionController::class);
    Route::get('permission-group/{groupName}/edit', [PermissionController::class, 'editGroup'])->name('permission.group.edit');
    Route::put('permission-group/{groupName}', [PermissionController::class, 'updateGroup'])->name('permission.group.update');
    Route::resource('role', RoleController::class);
    Route::resource('user', UserController::class);

    // ==========================================
    // Inventory Reports
    // ==========================================
    Route::get('reports/inventory', [App\Http\Controllers\Admin\Inventory\InventoryReportController::class, 'index'])->name('reports.inventory.index');
    Route::get('reports/inventory/usage', [App\Http\Controllers\Admin\Inventory\InventoryReportController::class, 'usage'])->name('reports.inventory.usage');
    Route::get('reports/inventory/request-variance', [App\Http\Controllers\Admin\Inventory\InventoryReportController::class, 'requestVariance'])->name('reports.inventory.request-variance');
    Route::get('reports/inventory/reconciliation', [App\Http\Controllers\Admin\Inventory\InventoryReportController::class, 'reconciliation'])->name('reports.inventory.reconciliation');
    Route::get('reports/inventory/qa', [App\Http\Controllers\Admin\Inventory\InventoryReportController::class, 'qa'])->name('reports.inventory.qa');

    // ==========================================
    // Inventory - Phase 1 through Phase 8
    // ==========================================
    Route::prefix('inventory')->name('inventory.')->group(function () {
        Route::get('/dashboard', [App\Http\Controllers\Admin\Inventory\InventoryDashboardController::class, 'index'])->name('dashboard');
        Route::get('/kitchen-dashboard', [App\Http\Controllers\Admin\Inventory\InventoryDashboardController::class, 'kitchen'])->name('kitchen-dashboard');
        Route::get('/units', [App\Http\Controllers\Admin\Inventory\UnitController::class, 'index'])->name('units.index');
        Route::post('/units', [App\Http\Controllers\Admin\Inventory\UnitController::class, 'store'])->name('units.store');
        Route::put('/units/{unit}', [App\Http\Controllers\Admin\Inventory\UnitController::class, 'update'])->name('units.update');
        Route::delete('/units/{unit}', [App\Http\Controllers\Admin\Inventory\UnitController::class, 'destroy'])->name('units.destroy');

        Route::get('/recipes', [App\Http\Controllers\Admin\Inventory\RecipeController::class, 'index'])->name('recipes.index');
        Route::get('/recipes/{food}/edit', [App\Http\Controllers\Admin\Inventory\RecipeController::class, 'edit'])->name('recipes.edit');
        Route::put('/recipes/{food}', [App\Http\Controllers\Admin\Inventory\RecipeController::class, 'update'])->name('recipes.update');
        Route::get('/ingredients', [App\Http\Controllers\Admin\Inventory\IngredientController::class, 'index'])->name('ingredients.index');
        Route::get('/ingredients/create', [App\Http\Controllers\Admin\Inventory\IngredientController::class, 'create'])->name('ingredients.create');
        Route::post('/ingredients', [App\Http\Controllers\Admin\Inventory\IngredientController::class, 'store'])->name('ingredients.store');
        Route::get('/ingredients/{ingredient}', [App\Http\Controllers\Admin\Inventory\IngredientController::class, 'show'])->name('ingredients.show');
        Route::get('/ingredients/{ingredient}/edit', [App\Http\Controllers\Admin\Inventory\IngredientController::class, 'edit'])->name('ingredients.edit');
        Route::put('/ingredients/{ingredient}', [App\Http\Controllers\Admin\Inventory\IngredientController::class, 'update'])->name('ingredients.update');
        Route::delete('/ingredients/{ingredient}', [App\Http\Controllers\Admin\Inventory\IngredientController::class, 'destroy'])->name('ingredients.destroy');

        Route::post('/vendors/{vendor}/payments', [App\Http\Controllers\Admin\Inventory\VendorController::class, 'storePayment'])->name('vendors.payments.store');
        Route::get('/vendors/{vendor}/documents/{type}', [App\Http\Controllers\Admin\Inventory\VendorController::class, 'document'])->name('vendors.document');
        Route::resource('vendors', App\Http\Controllers\Admin\Inventory\VendorController::class);

        Route::get('/purchase-approval-settings', [App\Http\Controllers\Admin\Inventory\PurchaseApprovalSettingController::class, 'index'])->name('purchase-approval-settings.index');
        Route::put('/purchase-approval-settings', [App\Http\Controllers\Admin\Inventory\PurchaseApprovalSettingController::class, 'update'])->name('purchase-approval-settings.update');

        Route::get('/purchase-approvals', [App\Http\Controllers\Admin\Inventory\PurchaseApprovalController::class, 'index'])->name('purchase-approvals.index');
        Route::post('/purchase-vouchers/{purchaseVoucher}/approve', [App\Http\Controllers\Admin\Inventory\PurchaseApprovalController::class, 'approve'])->name('purchase-vouchers.approve');
        Route::post('/purchase-vouchers/{purchaseVoucher}/reject', [App\Http\Controllers\Admin\Inventory\PurchaseApprovalController::class, 'reject'])->name('purchase-vouchers.reject');

        Route::get('/purchase-vouchers/{purchaseVoucher}/pdf', [App\Http\Controllers\Admin\Inventory\PurchaseVoucherController::class, 'pdf'])->name('purchase-vouchers.pdf');
        Route::post('/purchase-vouchers/{purchaseVoucher}/submit', [App\Http\Controllers\Admin\Inventory\PurchaseVoucherController::class, 'submit'])->name('purchase-vouchers.submit');
        Route::get('/purchase-vouchers/{purchaseVoucher}/approval-history', [App\Http\Controllers\Admin\Inventory\PurchaseVoucherController::class, 'approvalHistory'])->name('purchase-vouchers.approval-history');
        Route::post('/purchase-vouchers/{purchaseVoucher}/dispatch-approval', [App\Http\Controllers\Admin\Inventory\PurchaseVoucherController::class, 'dispatchApproval'])->name('purchase-vouchers.dispatch-approval');
        Route::post('/purchase-vouchers/{purchaseVoucher}/send-to-vendor', [App\Http\Controllers\Admin\Inventory\PurchaseVoucherController::class, 'sendToVendor'])->name('purchase-vouchers.send-to-vendor');
        Route::get('/purchase-vouchers/{purchaseVoucher}/receive-supply', [App\Http\Controllers\Admin\Inventory\PurchaseVoucherController::class, 'receiveSupply'])->name('purchase-vouchers.receive-supply');
        Route::resource('purchase-vouchers', App\Http\Controllers\Admin\Inventory\PurchaseVoucherController::class)->parameters(['purchase-vouchers' => 'purchaseVoucher']);

        Route::get('/purchases/{purchase}/invoice-pdf', [App\Http\Controllers\Admin\Inventory\PurchaseController::class, 'invoicePdf'])->name('purchases.invoice-pdf');
        Route::get('/purchases/{purchase}/original-invoice', [App\Http\Controllers\Admin\Inventory\PurchaseController::class, 'downloadOriginalInvoice'])->name('purchases.original-invoice');
        Route::resource('purchases', App\Http\Controllers\Admin\Inventory\PurchaseController::class);
        Route::post('/purchases/{purchase}/receive', [App\Http\Controllers\Admin\Inventory\PurchaseController::class, 'receive'])->name('purchases.receive');

        Route::resource('kitchen-requests', App\Http\Controllers\Admin\Inventory\KitchenRequestController::class);
        Route::get('/kitchen-requests/{kitchenRequest}/assign', [App\Http\Controllers\Admin\Inventory\KitchenRequestController::class, 'assign'])->name('kitchen-requests.assign');
        Route::post('/kitchen-requests/{kitchenRequest}/submit', [App\Http\Controllers\Admin\Inventory\KitchenRequestController::class, 'submit'])->name('kitchen-requests.submit');
        Route::post('/kitchen-requests/{kitchenRequest}/cancel', [App\Http\Controllers\Admin\Inventory\KitchenRequestController::class, 'cancel'])->name('kitchen-requests.cancel');
        Route::post('/kitchen-requests/{kitchenRequest}/close', [App\Http\Controllers\Admin\Inventory\KitchenRequestController::class, 'close'])->name('kitchen-requests.close');
        Route::post('/kitchen-requests/{kitchenRequest}/assign', [App\Http\Controllers\Admin\Inventory\KitchenRequestController::class, 'issue'])->name('kitchen-requests.assign.store');

        Route::get('/transfers/return/create', [App\Http\Controllers\Admin\Inventory\StockTransferController::class, 'returnCreate'])->name('transfers.return.create');
        Route::post('/transfers/return', [App\Http\Controllers\Admin\Inventory\StockTransferController::class, 'returnStore'])->name('transfers.return.store');
        Route::get('/transfers/{transfer}', [App\Http\Controllers\Admin\Inventory\StockTransferController::class, 'show'])->name('transfers.show');

        Route::resource('wastages', App\Http\Controllers\Admin\Inventory\WastageController::class)->only(['index', 'create', 'store', 'show', 'edit', 'update', 'destroy']);
        Route::get('/adjustments/create', [App\Http\Controllers\Admin\Inventory\AdjustmentController::class, 'create'])->name('adjustments.create');
        Route::post('/adjustments', [App\Http\Controllers\Admin\Inventory\AdjustmentController::class, 'store'])->name('adjustments.store');
        Route::get('/negative-stock-adjustments', [App\Http\Controllers\Admin\Inventory\NegativeStockAdjustmentController::class, 'index'])->name('negative-stock-adjustments.index');
        Route::post('/negative-stock-adjustments', [App\Http\Controllers\Admin\Inventory\NegativeStockAdjustmentController::class, 'store'])->name('negative-stock-adjustments.store');

        Route::get('/stock', [App\Http\Controllers\Admin\Inventory\StockController::class, 'index'])->name('stock.index');
        Route::post('/stock/opening', [App\Http\Controllers\Admin\Inventory\StockController::class, 'storeOpeningStock'])->name('stock.opening.store');
        Route::get('/ledger', [App\Http\Controllers\Admin\Inventory\LedgerController::class, 'index'])->name('ledger.index');
    });


    // Profile Routes
    Route::get('/my-profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::put('/my-profile/update', [ProfileController::class, 'update'])->name('profile.update');
    Route::put('/my-profile/password', [ProfileController::class, 'updatePassword'])->name('profile.password.update');


    // ==========================================
    // Human Resources - HR Settings Routes
    // ==========================================
    Route::prefix('hr')->name('hr.')->group(function () {
        Route::get('/dashboard', [HrDashboardController::class, 'index'])->name('dashboard');

        Route::get('/employees', [EmployeeController::class, 'index'])->name('employees.index');
        Route::get('/employees/create', [EmployeeController::class, 'create'])->name('employees.create');
        Route::post('/employees', [EmployeeController::class, 'store'])->name('employees.store');
        Route::get('/employees/{employee}', [EmployeeController::class, 'show'])->name('employees.show');
        Route::get('/employees/{employee}/edit', [EmployeeController::class, 'edit'])->name('employees.edit');
        Route::put('/employees/{employee}', [EmployeeController::class, 'update'])->name('employees.update');
        Route::patch('/employees/{employee}/status', [EmployeeController::class, 'updateStatus'])->name('employees.status');
        Route::delete('/employees/bulk', [EmployeeController::class, 'bulkDestroy'])->name('employees.bulk.destroy');
        Route::delete('/employees/{employee}', [EmployeeController::class, 'destroy'])->name('employees.destroy');
        Route::get('/employees/{employee}/salary', [EmployeeSalaryController::class, 'show'])->name('employees.salary.show');
        Route::post('/employees/{employee}/salary', [EmployeeSalaryController::class, 'store'])->name('employees.salary.store');

        Route::get('/attendance', [AttendanceController::class, 'index'])->name('attendance.index');
        Route::get('/attendance/template/download', [AttendanceController::class, 'downloadTemplate'])->name('attendance.template.download');
        Route::post('/attendance/import', [AttendanceController::class, 'importExcel'])->name('attendance.import');
        Route::get('/attendance/reports', [AttendanceController::class, 'reports'])->name('attendance.reports.index');
        Route::get('/attendance/reports/table', [AttendanceController::class, 'reportTable'])->name('attendance.reports.table');
        Route::get('/attendance/reports/pdf', [AttendanceController::class, 'reportPdf'])->name('attendance.reports.pdf');
        Route::get('/attendance/reports/excel', [AttendanceController::class, 'reportExcel'])->name('attendance.reports.excel');
        Route::post('/attendance/bulk', [AttendanceController::class, 'storeBulk'])->name('attendance.bulk.store');
        Route::put('/attendance/{attendance}', [AttendanceController::class, 'update'])->name('attendance.update');
        Route::delete('/attendance/{attendance}', [AttendanceController::class, 'destroy'])->name('attendance.destroy');

        Route::post('/tipsoi/test', [TipsoiController::class, 'testConnection'])->name('tipsoi.test');

        Route::get('/tipsoi/people', [TipsoiController::class, 'people'])->name('tipsoi.people.index');
        Route::post('/tipsoi/people/refresh', [TipsoiController::class, 'refreshPeople'])->name('tipsoi.people.refresh');
        Route::post('/tipsoi/employees/pull', [TipsoiController::class, 'pullEmployees'])->name('tipsoi.employees.pull');
        Route::post('/tipsoi/employees/push', [TipsoiController::class, 'pushEmployees'])->name('tipsoi.employees.push');
        Route::post('/tipsoi/employees/{employee}/push', [TipsoiController::class, 'pushEmployee'])->name('tipsoi.employees.push-one');

        Route::get('/tipsoi/devices', [TipsoiController::class, 'devices'])->name('tipsoi.devices.index');
        Route::post('/tipsoi/devices/refresh', [TipsoiController::class, 'refreshDevices'])->name('tipsoi.devices.refresh');

        Route::get('/tipsoi/fingerprint', [TipsoiController::class, 'fingerprint'])->name('tipsoi.fingerprint.index');
        Route::post('/tipsoi/fingerprint/start', [TipsoiController::class, 'startEnrollment'])->name('tipsoi.fingerprint.start');
        Route::post('/tipsoi/fingerprint/stop', [TipsoiController::class, 'stopEnrollment'])->name('tipsoi.fingerprint.stop');
        Route::get('/tipsoi/fingerprint/status', [TipsoiController::class, 'enrollmentStatus'])->name('tipsoi.fingerprint.status');

        Route::get('/tipsoi/allocations', [TipsoiController::class, 'allocations'])->name('tipsoi.allocations.index');
        Route::post('/tipsoi/allocations', [TipsoiController::class, 'allocate'])->name('tipsoi.allocations.store');
        Route::post('/tipsoi/allocations/batch', [TipsoiController::class, 'batchAllocation'])->name('tipsoi.allocations.batch');

        Route::get('/tipsoi/raw-logs', [TipsoiController::class, 'rawLogs'])->name('tipsoi.raw-logs.index');
        Route::post('/tipsoi/raw-logs/refresh', [TipsoiController::class, 'refreshRawLogs'])->name('tipsoi.raw-logs.refresh');
        Route::get('/tipsoi/sync-history', [TipsoiController::class, 'syncHistory'])->name('tipsoi.sync-history.index');

        Route::post('/tipsoi/attendance/pull', [TipsoiController::class, 'pullAttendance'])->name('tipsoi.attendance.pull');
        Route::post('/tipsoi/attendance/auto-sync', [TipsoiController::class, 'autoSyncAttendance'])->name('tipsoi.attendance.auto-sync');


        Route::get('/leave-management', [LeaveManagementController::class, 'index'])->name('leaves.index');
        Route::get('/leave-management/employee/{employee}/balances', [LeaveManagementController::class, 'balances'])->name('leaves.balances');
        Route::post('/leave-management', [LeaveManagementController::class, 'store'])->name('leaves.store');
        Route::post('/leave-management/{leave}', [LeaveManagementController::class, 'update'])->name('leaves.update');
        Route::patch('/leave-management/{leave}/decision', [LeaveManagementController::class, 'decision'])->name('leaves.decision');
        Route::patch('/leave-management/{leave}/cancel', [LeaveManagementController::class, 'cancel'])->name('leaves.cancel');
        Route::delete('/leave-management/{leave}', [LeaveManagementController::class, 'destroy'])->name('leaves.destroy');


        Route::get('/salary-advances', [SalaryAdvanceController::class, 'index'])->name('salary-advances.index');
        Route::post('/salary-advances', [SalaryAdvanceController::class, 'store'])->name('salary-advances.store');
        Route::put('/salary-advances/{salaryAdvance}', [SalaryAdvanceController::class, 'update'])->name('salary-advances.update');
        Route::post('/salary-advances/{salaryAdvance}/repay', [SalaryAdvanceController::class, 'repay'])->name('salary-advances.repay');
        Route::delete('/salary-advances/{salaryAdvance}', [SalaryAdvanceController::class, 'destroy'])->name('salary-advances.destroy');

        Route::get('/loans', [LoanController::class, 'index'])->name('loans.index');
        Route::post('/loans', [LoanController::class, 'store'])->name('loans.store');
        Route::put('/loans/{loan}', [LoanController::class, 'update'])->name('loans.update');
        Route::post('/loans/{loan}/repay', [LoanController::class, 'repay'])->name('loans.repay');
        Route::delete('/loans/{loan}', [LoanController::class, 'destroy'])->name('loans.destroy');


        Route::get('/payroll', [PayrollController::class, 'index'])->name('payroll.index');
        Route::get('/payroll/create', [PayrollController::class, 'create'])->name('payroll.create');
        Route::get('/payroll/precheck', [PayrollController::class, 'precheck'])->name('payroll.precheck');
        Route::post('/payroll', [PayrollController::class, 'store'])->name('payroll.store');
        Route::get('/payroll/single/create', [PayrollController::class, 'createSingle'])->name('payroll.single.create');
        Route::get('/payroll/single/precheck', [PayrollController::class, 'singlePrecheck'])->name('payroll.single.precheck');
        Route::post('/payroll/single', [PayrollController::class, 'storeSingle'])->name('payroll.single.store');
        Route::get('/payroll/{payrollRun}', [PayrollController::class, 'show'])->name('payroll.show');
        Route::get('/payroll/{payrollRun}/items/table', [PayrollController::class, 'itemsTable'])->name('payroll.items.table');
        Route::get('/payroll/{payrollRun}/items/{payrollItem}', [PayrollController::class, 'itemShow'])->name('payroll.items.show');
        Route::put('/payroll/{payrollRun}/items/{payrollItem}', [PayrollController::class, 'updateItem'])->name('payroll.items.update');
        Route::post('/payroll/{payrollRun}/approve', [PayrollController::class, 'approve'])->name('payroll.approve');
        Route::post('/payroll/{payrollRun}/items/{payrollItem}/approve', [PayrollController::class, 'approveItem'])->name('payroll.items.approve');
        Route::post('/payroll/{payrollRun}/items/{payrollItem}/pay', [PayrollController::class, 'payItem'])->name('payroll.items.pay');
        Route::post('/payroll/{payrollRun}/pay-all', [PayrollController::class, 'payAll'])->name('payroll.pay-all');
        Route::post('/payroll/{payrollRun}/regenerate', [PayrollController::class, 'regenerate'])->name('payroll.regenerate');
        Route::delete('/payroll/{payrollRun}', [PayrollController::class, 'destroy'])->name('payroll.destroy');
        Route::get('/payroll/{payrollRun}/summary-pdf', [PayrollController::class, 'summaryPdf'])->name('payroll.summary-pdf');
        Route::get('/payroll/{payrollRun}/items/{payrollItem}/payslip', [PayrollController::class, 'payslip'])->name('payroll.items.payslip');

        Route::get('/shifts', [HrShiftController::class, 'index'])->name('shifts.index');
        Route::get('/shifts/table/list', [HrShiftController::class, 'shiftTable'])->name('shifts.table');
        Route::post('/shifts', [HrShiftController::class, 'store'])->name('shifts.store');
        Route::put('/shifts/{shift}', [HrShiftController::class, 'update'])->name('shifts.update');
        Route::patch('/shifts/{shift}/status', [HrShiftController::class, 'updateStatus'])->name('shifts.status');
        Route::delete('/shifts/{shift}', [HrShiftController::class, 'destroy'])->name('shifts.destroy');
        Route::get('/shift-roster/table', [HrShiftController::class, 'rosterTable'])->name('shifts.roster.table');
        Route::post('/shift-roster/save', [HrShiftController::class, 'saveRoster'])->name('shifts.roster.save');
        Route::post('/shift-roster/copy-previous', [HrShiftController::class, 'copyPreviousWeek'])->name('shifts.roster.copy');

        Route::get('/settings', [HrSettingController::class, 'index'])->name('settings.index');
        Route::post('/settings/general', [HrSettingController::class, 'updateGeneral'])->name('settings.general.update');
        Route::post('/settings/attendance', [HrSettingController::class, 'updateAttendance'])->name('settings.attendance.update');
        Route::post('/settings/payroll', [HrSettingController::class, 'updatePayroll'])->name('settings.payroll.update');
        Route::post('/settings/clean-data', [HrSettingController::class, 'cleanHrData'])->name('settings.clean-data');

        Route::post('/settings/departments', [HrSettingController::class, 'storeDepartment'])->name('settings.departments.store');
        Route::put('/settings/departments/{department}', [HrSettingController::class, 'updateDepartment'])->name('settings.departments.update');
        Route::patch('/settings/departments/{department}/status', [HrSettingController::class, 'updateDepartmentStatus'])->name('settings.departments.status');
        Route::delete('/settings/departments/{department}', [HrSettingController::class, 'destroyDepartment'])->name('settings.departments.destroy');

        Route::post('/settings/designations', [HrSettingController::class, 'storeDesignation'])->name('settings.designations.store');
        Route::put('/settings/designations/{designation}', [HrSettingController::class, 'updateDesignation'])->name('settings.designations.update');
        Route::patch('/settings/designations/{designation}/status', [HrSettingController::class, 'updateDesignationStatus'])->name('settings.designations.status');
        Route::delete('/settings/designations/{designation}', [HrSettingController::class, 'destroyDesignation'])->name('settings.designations.destroy');

        Route::post('/settings/employment-types', [HrSettingController::class, 'storeEmploymentType'])->name('settings.employment-types.store');
        Route::put('/settings/employment-types/{employmentType}', [HrSettingController::class, 'updateEmploymentType'])->name('settings.employment-types.update');
        Route::patch('/settings/employment-types/{employmentType}/status', [HrSettingController::class, 'updateEmploymentTypeStatus'])->name('settings.employment-types.status');
        Route::delete('/settings/employment-types/{employmentType}', [HrSettingController::class, 'destroyEmploymentType'])->name('settings.employment-types.destroy');

        Route::post('/settings/leave-types', [HrSettingController::class, 'storeLeaveType'])->name('settings.leave-types.store');
        Route::put('/settings/leave-types/{leaveType}', [HrSettingController::class, 'updateLeaveType'])->name('settings.leave-types.update');
        Route::patch('/settings/leave-types/{leaveType}/status', [HrSettingController::class, 'updateLeaveTypeStatus'])->name('settings.leave-types.status');
        Route::delete('/settings/leave-types/{leaveType}', [HrSettingController::class, 'destroyLeaveType'])->name('settings.leave-types.destroy');

        Route::post('/settings/salary-components', [HrSettingController::class, 'storeSalaryComponent'])->name('settings.salary-components.store');
        Route::put('/settings/salary-components/{salaryComponent}', [HrSettingController::class, 'updateSalaryComponent'])->name('settings.salary-components.update');
        Route::patch('/settings/salary-components/{salaryComponent}/status', [HrSettingController::class, 'updateSalaryComponentStatus'])->name('settings.salary-components.status');
        Route::delete('/settings/salary-components/{salaryComponent}', [HrSettingController::class, 'destroySalaryComponent'])->name('settings.salary-components.destroy');

        Route::post('/settings/holidays', [HrSettingController::class, 'storeHoliday'])->name('settings.holidays.store');
        Route::put('/settings/holidays/{holiday}', [HrSettingController::class, 'updateHoliday'])->name('settings.holidays.update');
        Route::patch('/settings/holidays/{holiday}/status', [HrSettingController::class, 'updateHolidayStatus'])->name('settings.holidays.status');
        Route::delete('/settings/holidays/{holiday}', [HrSettingController::class, 'destroyHoliday'])->name('settings.holidays.destroy');
    });

    // Settings Routes
    Route::get('/settings', [SettingController::class, 'index'])->name('settings.index');
    Route::post('/settings/restaurant', [SettingController::class, 'updateRestaurant'])->name('settings.restaurant');
    Route::post('/settings/tax', [SettingController::class, 'updateTax'])->name('settings.tax');
    Route::post('/settings/invoice', [SettingController::class, 'updateInvoice'])->name('settings.invoice');
    Route::post('/settings/pos', [SettingController::class, 'updatePos'])->name('settings.pos');
    Route::post('/settings/offline-pos', [SettingController::class, 'updateOfflinePos'])->name('settings.offline-pos');
    Route::post('/settings/pos/clear-transactions', [SettingController::class, 'clearPosTransactionData'])->name('settings.pos.clear-transactions');

    // Offline POS Device Management
    Route::get('/offline-pos-devices', [App\Http\Controllers\Admin\OfflinePosDeviceController::class, 'index'])->name('offline-pos-devices.index');
    Route::get('/offline-sync-logs', [App\Http\Controllers\Admin\OfflinePosSyncLogController::class, 'index'])->name('offline-sync-logs.index');
    Route::delete('/offline-sync-logs/bulk-delete', [App\Http\Controllers\Admin\OfflinePosSyncLogController::class, 'destroySelected'])->name('offline-sync-logs.bulk-delete');
    Route::post('/offline-pos-devices', [App\Http\Controllers\Admin\OfflinePosDeviceController::class, 'store'])->name('offline-pos-devices.store');
    Route::patch('/offline-pos-devices/{device}/toggle', [App\Http\Controllers\Admin\OfflinePosDeviceController::class, 'toggle'])->name('offline-pos-devices.toggle');
    Route::patch('/offline-pos-devices/{device}/reset-binding', [App\Http\Controllers\Admin\OfflinePosDeviceController::class, 'resetBinding'])->name('offline-pos-devices.reset-binding');
    Route::delete('/offline-pos-devices/{device}', [App\Http\Controllers\Admin\OfflinePosDeviceController::class, 'destroy'])->name('offline-pos-devices.destroy');
});
